﻿using System.ComponentModel;
using System.Diagnostics;
using System.Text;

namespace MeskTweaks
{
    public sealed class AppInfo
    {
        public string Nome { get; }
        public string Id { get; }          // ID do pacote no winget
        public string Categoria { get; }
        public string? Fonte { get; }      // ex.: "msstore" (opcional)

        public AppInfo(string categoria, string nome, string id, string? fonte = null)
        {
            Categoria = categoria;
            Nome = nome;
            Id = id;
            Fonte = fonte;
        }

        // Texto exibido na lista
        public override string ToString() => Nome + "   ·   " + Categoria;
    }

    /// <summary>
    /// Instala aplicativos usando o winget (Gerenciador de Pacotes do Windows 10/11).
    /// Os downloads vêm direto dos repositórios oficiais do winget.
    /// </summary>
    public static class InstaladorApps
    {
        // 0x8A150061 = pacote já instalado
        private const int JaInstalado = unchecked((int)0x8A150061);
        // 0x8A150056 = o instalador do app se recusa a rodar como administrador
        private const int ElevacaoProibida = unchecked((int)0x8A150056);

        public static readonly List<AppInfo> Apps = new List<AppInfo>
        {
            // Navegadores
            new AppInfo("Navegador", "Google Chrome",         "Google.Chrome"),
            new AppInfo("Navegador", "Mozilla Firefox",       "Mozilla.Firefox"),
            new AppInfo("Navegador", "Brave",                 "Brave.Brave"),

            // Comunicação
            new AppInfo("Comunicação", "Discord",             "Discord.Discord"),
            new AppInfo("Comunicação", "Telegram",            "Telegram.TelegramDesktop"),

            // Jogos
            new AppInfo("Jogos", "Steam",                     "Valve.Steam"),
            new AppInfo("Jogos", "Epic Games Launcher",       "EpicGames.EpicGamesLauncher"),

            // Mídia
            new AppInfo("Mídia", "Spotify",                   "9NCBCSZSJRSB", "msstore"),
            new AppInfo("Mídia", "VLC Media Player",          "VideoLAN.VLC"),
            new AppInfo("Mídia", "OBS Studio",                "OBSProject.OBSStudio"),
            new AppInfo("Mídia", "ShareX",                    "ShareX.ShareX"),

            // Utilitários
            new AppInfo("Utilitário", "7-Zip",                "7zip.7zip"),
            new AppInfo("Utilitário", "WinRAR",               "RARLab.WinRAR"),
            new AppInfo("Utilitário", "Everything (busca)",   "voidtools.Everything"),
            new AppInfo("Utilitário", "qBittorrent",          "qBittorrent.qBittorrent"),
            new AppInfo("Utilitário", "AnyDesk",              "AnyDeskSoftwareGmbH.AnyDesk"),

            // Desenvolvimento
            new AppInfo("Desenvolvimento", "Visual Studio Code", "Microsoft.VisualStudioCode"),
            new AppInfo("Desenvolvimento", "Notepad++",       "Notepad++.Notepad++"),
            new AppInfo("Desenvolvimento", "Git",             "Git.Git"),

            // Hardware / diagnóstico
            new AppInfo("Hardware", "HWiNFO",                 "REALiX.HWiNFO"),
            new AppInfo("Hardware", "CPU-Z",                  "CPUID.CPU-Z"),
            new AppInfo("Hardware", "MSI Afterburner",        "Guru3D.Afterburner"),
        };

        /// <summary>Verifica se o winget está disponível neste Windows.</summary>
        public static bool WingetDisponivel()
        {
            try
            {
                var psi = new ProcessStartInfo("winget.exe", "--version")
                {
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                using var p = Process.Start(psi);
                if (p == null) return false;
                p.WaitForExit(15000);
                return p.HasExited && p.ExitCode == 0;
            }
            catch (Win32Exception)
            {
                return false;
            }
        }

        /// <summary>Instala um aplicativo em modo silencioso.</summary>
        public static async Task<(bool Sucesso, string Mensagem)> InstalarAsync(AppInfo app)
        {
            try
            {
                var psi = new ProcessStartInfo("winget.exe",
                    "install --id " + app.Id + " -e --silent --disable-interactivity " +
                    (app.Fonte != null ? "--source " + app.Fonte + " " : "") +
                    "--accept-package-agreements --accept-source-agreements")
                {
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.UTF8
                };

                using var proc = Process.Start(psi);
                if (proc == null) return (false, "Não foi possível iniciar o winget.");

                // lê a saída para não travar o buffer
                var saida = proc.StandardOutput.ReadToEndAsync();
                var erro = proc.StandardError.ReadToEndAsync();

                using var cts = new CancellationTokenSource(TimeSpan.FromMinutes(20));
                try
                {
                    await proc.WaitForExitAsync(cts.Token);
                }
                catch (OperationCanceledException)
                {
                    try { proc.Kill(true); } catch { }
                    return (false, "Tempo esgotado (20 min).");
                }

                await Task.WhenAll(saida, erro);

                if (proc.ExitCode == 0) return (true, "Instalado.");
                if (proc.ExitCode == JaInstalado) return (true, "Já estava instalado.");

                if (proc.ExitCode == ElevacaoProibida)
                    return (false, "o instalador deste app não aceita rodar como administrador.");

                return (false, "winget retornou código " + proc.ExitCode + ".");
            }
            catch (Exception ex)
            {
                return (false, ex.Message);
            }
        }
    }
}