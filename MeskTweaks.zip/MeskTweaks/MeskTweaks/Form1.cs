using Microsoft.Win32;
using Sunny.UI;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace MeskTweaks
{
    public partial class Form1 : UIForm
    {
        // Paleta baseada no ícone (preto/roxo neon)
        private static readonly Color CorFundo = ColorTranslator.FromHtml("#0B0714");
        private static readonly Color CorSuperficie = ColorTranslator.FromHtml("#150E26");
        private static readonly Color CorPrimaria = ColorTranslator.FromHtml("#7C3AED");
        private static readonly Color CorHover = ColorTranslator.FromHtml("#9D5CFF");
        private static readonly Color CorPress = ColorTranslator.FromHtml("#5B21B6");
        private static readonly Color CorDestaque = ColorTranslator.FromHtml("#C084FC");
        private static readonly Color CorTexto = ColorTranslator.FromHtml("#F3E8FF");
        private static readonly Color CorTextoSuave = ColorTranslator.FromHtml("#9F8FC4");

        public Form1()
        {
            InitializeComponent();
            AplicarTema();
            CarregarApps();
            CarregarConfiguracoes();
            PreencherListaApps();
        }

        private void AplicarTema()
        {
            // Ícone da janela = ícone do .exe (definido em <ApplicationIcon> no .csproj)
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

            // Janela
            StyleCustomMode = true;
            Style = UIStyle.Custom;
            BackColor = CorFundo;
            ForeColor = CorTexto;
            TitleColor = CorSuperficie;
            TitleForeColor = CorTexto;
            RectColor = CorPrimaria;
            ShowIcon = true;
            ShowTitleIcon = true;

            // Menu lateral
            uiTabControlMenu1.StyleCustomMode = true;
            uiTabControlMenu1.Style = UIStyle.Custom;
            uiTabControlMenu1.FillColor = CorFundo;
            uiTabControlMenu1.BackColor = CorFundo;
            uiTabControlMenu1.TabBackColor = CorSuperficie;
            uiTabControlMenu1.TabSelectedColor = CorPrimaria;
            uiTabControlMenu1.TabSelectedForeColor = Color.White;
            uiTabControlMenu1.TabSelectedHighColor = CorDestaque;
            uiTabControlMenu1.TabUnSelectedForeColor = CorTextoSuave;

            tabPage1.BackColor = CorFundo;
            tabPage2.BackColor = CorFundo;
            tabPage3.BackColor = CorFundo;
            tabPage5.BackColor = CorFundo;
            tabPage6.BackColor = CorFundo;
            tabPage7.BackColor = CorFundo;

            // Botões
            EstilizarBotao(uiButton1, preenchido: true);
            EstilizarBotao(uiButton2, preenchido: false);
            EstilizarBotao(uiButton3, preenchido: false);
            EstilizarBotao(uiButton4, preenchido: true);
            EstilizarBotao(uiButton5, preenchido: true);
            EstilizarBotao(uiButton7, preenchido: true);
            EstilizarBotao(uiButton8, preenchido: false);
            EstilizarBotao(uiButton9, preenchido: false);
            EstilizarBotao(uiButton10, preenchido: false);
            EstilizarBotao(uiButton11, preenchido: false);
            EstilizarBotao(uiButton12, preenchido: true);
            EstilizarBotao(uiButton13, preenchido: true);

            // Lista de aplicativos
            checkedListBox1.BackColor = CorSuperficie;
            checkedListBox1.ForeColor = CorTexto;
        }

        private static void EstilizarBotao(UIButton b, bool preenchido)
        {
            b.StyleCustomMode = true;
            b.Style = UIStyle.Custom;
            b.Radius = 14;
            b.RectColor = CorPrimaria;
            b.RectHoverColor = CorHover;
            b.RectPressColor = CorPress;
            b.ForeColor = Color.White;
            b.ForeHoverColor = Color.White;
            b.ForePressColor = Color.White;

            if (preenchido)
            {
                b.FillColor = CorPrimaria;
                b.FillHoverColor = CorHover;
                b.FillPressColor = CorPress;
            }
            else
            {
                b.FillColor = CorSuperficie;
                b.FillHoverColor = CorPress;
                b.FillPressColor = CorPrimaria;
            }
        }

        private static bool EhAdministrador()
        {
            using var id = WindowsIdentity.GetCurrent();
            return new WindowsPrincipal(id).IsInRole(WindowsBuiltInRole.Administrator);
        }

        // =================== Aba Privacidade ===================

        // Desativar tudo
        private async void uiButton1_Click(object? sender, EventArgs e)
        {
            await Executar(PoliticasWindows.DesativarTudo, "Todas as funções foram desativadas!");
        }

        // Voltar ao padrão do Windows
        private async void uiButton2_Click(object? sender, EventArgs e)
        {
            await Executar(PoliticasWindows.RestaurarPadrao, "Configurações restauradas ao padrão do Windows!");
        }

        private async Task Executar(Func<List<string>> acao, string msgFinal)
        {
            if (!EhAdministrador())
            {
                UIMessageBox.ShowError("Execute o programa como Administrador.");
                return;
            }

            uiButton1.Enabled = false;
            uiButton2.Enabled = false;
            lblStatus.Text = "Aplicando... aguarde.";

            try
            {
                List<string> log = await Task.Run(acao);
                var erros = log.Where(l => l.Contains("ERRO")).ToList();

                if (erros.Count == 0)
                {
                    lblStatus.Text = "Concluído com sucesso.";
                    UIMessageBox.ShowSuccess(msgFinal + "\nReinicie o PC para efeito completo.");
                }
                else
                {
                    lblStatus.Text = "Concluído com " + erros.Count + " erro(s).";
                    UIMessageBox.ShowWarning("Concluído com " + erros.Count + " erro(s):\n" + string.Join("\n", erros));
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Falha.";
                UIMessageBox.ShowError("Erro: " + ex.Message);
            }
            finally
            {
                uiButton1.Enabled = true;
                uiButton2.Enabled = true;
            }
        }

        // =================== Aba Aplicativos ===================

        private void CarregarApps()
        {
            checkedListBox1.Items.Clear();
            foreach (var app in InstaladorApps.Apps)
                checkedListBox1.Items.Add(app, false);
        }

        // Selecionar todos / limpar seleção
        private void uiButton3_Click(object? sender, EventArgs e)
        {
            bool marcarTodos = checkedListBox1.CheckedItems.Count < checkedListBox1.Items.Count;
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
                checkedListBox1.SetItemChecked(i, marcarTodos);

            uiButton3.Text = marcarTodos ? "Limpar seleção" : "Selecionar todos";
        }

        // Instalar selecionados
        private async void uiButton4_Click(object? sender, EventArgs e)
        {
            var selecionados = checkedListBox1.CheckedItems.Cast<AppInfo>().ToList();
            if (selecionados.Count == 0)
            {
                UIMessageBox.ShowWarning("Marque pelo menos um aplicativo.");
                return;
            }

            if (!await Task.Run(InstaladorApps.WingetDisponivel))
            {
                UIMessageBox.ShowError("O winget não foi encontrado.\nInstale o \"Instalador de Aplicativo\" (App Installer) pela Microsoft Store.");
                return;
            }

            uiButton3.Enabled = false;
            uiButton4.Enabled = false;
            checkedListBox1.Enabled = false;
            progressBar1.Maximum = selecionados.Count;
            progressBar1.Value = 0;

            var falhas = new List<string>();

            for (int i = 0; i < selecionados.Count; i++)
            {
                var app = selecionados[i];
                lblStatusApps.Text = "Instalando " + app.Nome + " (" + (i + 1) + "/" + selecionados.Count + ")...";

                var resultado = await InstaladorApps.InstalarAsync(app);
                if (!resultado.Sucesso) falhas.Add(app.Nome + ": " + resultado.Mensagem);

                progressBar1.Value = i + 1;
            }

            checkedListBox1.Enabled = true;
            uiButton3.Enabled = true;
            uiButton4.Enabled = true;

            if (falhas.Count == 0)
            {
                lblStatusApps.Text = "Todos os aplicativos foram instalados.";
                UIMessageBox.ShowSuccess("Instalação concluída!");
            }
            else
            {
                lblStatusApps.Text = "Concluído com " + falhas.Count + " falha(s).";
                UIMessageBox.ShowWarning("Falha em " + falhas.Count + " aplicativo(s):\n" + string.Join("\n", falhas));
            }
        }

        // =================== Aba Ferramentas ===================

        private const string UrlDControl = "https://github.com/0Mesk/MeskTweak/raw/refs/heads/main/dControl.zip";

        private async void uiButton5_Click(object? sender, EventArgs e)
        {
            uiButton5.Enabled = false;
            lblStatusFerramentas.Text = "Iniciando...";

            var progresso = new Progress<string>(msg => lblStatusFerramentas.Text = msg);

            var resultado = await Ferramentas.BaixarExtrairExecutarAsync(
                UrlDControl, "DControl", "DControl.exe", progresso);

            if (resultado.Sucesso)
            {
                lblStatusFerramentas.Text = "DControl iniciado.";
                UIMessageBox.ShowSuccess("DControl baixado e executado com sucesso!");
            }
            else
            {
                lblStatusFerramentas.Text = "Falha: " + resultado.Mensagem;
                UIMessageBox.ShowError("Não foi possível baixar/executar o DControl:\n" + resultado.Mensagem);
            }

            uiButton5.Enabled = true;
        }

        // =================== Aba Configurações ===================

        private const string KPersonalize = @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize";
        private const string KAvancado = @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced";
        private const string KPush = @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\PushNotifications";
        private const string KBusca = @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Search";
        private const string KConteudo = @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager";
        private const string KGameBar = @"HKEY_CURRENT_USER\Software\Microsoft\GameBar";
        private const string SubMenuClassico = @"Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}";

        // Política que liga/desliga os Widgets (precisa de Administrador)
        private const string SubPoliticaWidgets = @"SOFTWARE\Policies\Microsoft\Dsh";

        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessageTimeout(
            IntPtr hWnd, uint Msg, UIntPtr wParam, string lParam,
            uint fuFlags, uint uTimeout, out UIntPtr lpdwResult);

        private static int LerInt(string chave, string nome, int padrao)
        {
            try
            {
                object? v = Registry.GetValue(chave, nome, padrao);
                return v is int i ? i : padrao;
            }
            catch
            {
                return padrao;
            }
        }

        private static void GravarInt(string chave, string nome, int valor)
        {
            Registry.SetValue(chave, nome, valor, RegistryValueKind.DWord);
        }

        private static bool MenuClassicoAtivo()
        {
            try
            {
                using var k = Registry.CurrentUser.OpenSubKey(SubMenuClassico + @"\InprocServer32");
                return k != null;
            }
            catch
            {
                return false;
            }
        }

        // Widgets ligados? (considera o valor do usuário e a política do sistema)
        private static bool WidgetsAtivos()
        {
            try
            {
                using var k = Registry.LocalMachine.OpenSubKey(SubPoliticaWidgets);
                if (k?.GetValue("AllowNewsAndInterests") is int politica && politica == 0)
                    return false;
            }
            catch { }

            return LerInt(KAvancado, "TaskbarDa", 1) == 1;
        }

        // Liga/desliga Widgets. Em versões novas do Windows 11 o Windows pode devolver
        // "operação não autorizada" mesmo quando o ajuste é aplicado. Por isso as exceções
        // das gravações são ignoradas e o resultado é conferido lendo o valor de volta:
        // só reporta erro se o estado final realmente não ficou como o desejado.
        private static void DefinirWidgets(bool mostrar)
        {
            // 1) valor do usuário
            try { GravarInt(KAvancado, "TaskbarDa", mostrar ? 1 : 0); }
            catch { }

            // 2) política do sistema (precisa de Administrador)
            try
            {
                if (mostrar)
                {
                    using var k = Registry.LocalMachine.OpenSubKey(SubPoliticaWidgets, writable: true);
                    k?.DeleteValue("AllowNewsAndInterests", false);
                }
                else
                {
                    using var k = Registry.LocalMachine.CreateSubKey(SubPoliticaWidgets);
                    k?.SetValue("AllowNewsAndInterests", 0, RegistryValueKind.DWord);
                }
            }
            catch { }

            // 3) confere o resultado
            if (WidgetsAtivos() != mostrar)
                throw new InvalidOperationException(
                    "o valor não mudou. Tente abrir o programa como Administrador e clique em Reiniciar Explorer.");
        }

        // Lê o estado atual do Windows e marca/desmarca as caixas
        private void CarregarConfiguracoes()
        {
            chkTemaEscuro.Checked = LerInt(KPersonalize, "AppsUseLightTheme", 1) == 0;
            chkTransparencia.Checked = LerInt(KPersonalize, "EnableTransparency", 1) == 1;
            chkNotificacoes.Checked = LerInt(KPush, "ToastEnabled", 1) == 1;
            chkSugestoes.Checked = LerInt(KConteudo, "SubscribedContent-338388Enabled", 1) == 1;
            chkModoJogo.Checked = LerInt(KGameBar, "AutoGameModeEnabled", 1) == 1;
            chkExtensoes.Checked = LerInt(KAvancado, "HideFileExt", 1) == 0;

            chkOcultos.Checked = LerInt(KAvancado, "Hidden", 2) == 1;
            chkMenuClassico.Checked = MenuClassicoAtivo();
            chkBarraEsquerda.Checked = LerInt(KAvancado, "TaskbarAl", 1) == 0;
            chkWidgets.Checked = WidgetsAtivos();
            chkBusca.Checked = LerInt(KBusca, "SearchboxTaskbarMode", 1) != 0;
            chkVisaoTarefas.Checked = LerInt(KAvancado, "ShowTaskViewButton", 1) == 1;
        }

        // Carregar atuais
        private void uiButton8_Click(object? sender, EventArgs e)
        {
            CarregarConfiguracoes();
            lblStatusConfig.Text = "Valores atuais do Windows carregados.";
        }

        // Aplicar configurações
        private void uiButton7_Click(object? sender, EventArgs e)
        {
            var erros = new List<string>();

            void Tentar(string nome, Action acao)
            {
                try { acao(); }
                catch (Exception ex) { erros.Add(nome + ": " + ex.Message); }
            }

            // Tema (apps + sistema)
            Tentar("Tema", () =>
            {
                int claro = chkTemaEscuro.Checked ? 0 : 1;
                GravarInt(KPersonalize, "AppsUseLightTheme", claro);
                GravarInt(KPersonalize, "SystemUsesLightTheme", claro);
            });

            Tentar("Transparência", () =>
                GravarInt(KPersonalize, "EnableTransparency", chkTransparencia.Checked ? 1 : 0));

            Tentar("Notificações", () =>
                GravarInt(KPush, "ToastEnabled", chkNotificacoes.Checked ? 1 : 0));

            Tentar("Sugestões e anúncios", () =>
            {
                int v = chkSugestoes.Checked ? 1 : 0;
                string[] nomes =
                {
                    "SubscribedContent-338388Enabled",
                    "SubscribedContent-338389Enabled",
                    "SubscribedContent-353694Enabled",
                    "SubscribedContent-353696Enabled",
                    "SystemPaneSuggestionsEnabled",
                    "SoftLandingEnabled"
                };
                foreach (var n in nomes)
                    GravarInt(KConteudo, n, v);
            });

            Tentar("Modo de jogo", () =>
                GravarInt(KGameBar, "AutoGameModeEnabled", chkModoJogo.Checked ? 1 : 0));

            Tentar("Extensões de arquivos", () =>
                GravarInt(KAvancado, "HideFileExt", chkExtensoes.Checked ? 0 : 1));

            Tentar("Arquivos ocultos", () =>
                GravarInt(KAvancado, "Hidden", chkOcultos.Checked ? 1 : 2));

            Tentar("Menu de contexto clássico", () =>
            {
                if (chkMenuClassico.Checked)
                {
                    using var k = Registry.CurrentUser.CreateSubKey(SubMenuClassico + @"\InprocServer32");
                    k?.SetValue("", "", RegistryValueKind.String);
                }
                else
                {
                    Registry.CurrentUser.DeleteSubKeyTree(SubMenuClassico, false);
                }
            });

            Tentar("Barra de tarefas à esquerda", () =>
                GravarInt(KAvancado, "TaskbarAl", chkBarraEsquerda.Checked ? 0 : 1));

            Tentar("Widgets", () => DefinirWidgets(chkWidgets.Checked));

            Tentar("Pesquisa na barra", () =>
                GravarInt(KBusca, "SearchboxTaskbarMode", chkBusca.Checked ? 1 : 0));

            Tentar("Visão de Tarefas", () =>
                GravarInt(KAvancado, "ShowTaskViewButton", chkVisaoTarefas.Checked ? 1 : 0));

            // Avisa o Windows que o tema/configurações mudaram
            try
            {
                SendMessageTimeout((IntPtr)0xFFFF, 0x001A, UIntPtr.Zero, "ImmersiveColorSet", 0x2, 1000, out _);
            }
            catch { }

            if (erros.Count == 0)
            {
                lblStatusConfig.Text = "Configurações aplicadas. Clique em \"Reiniciar Explorer\" para atualizar a barra e o menu.";
                UIMessageBox.ShowSuccess("Configurações aplicadas!");
            }
            else
            {
                lblStatusConfig.Text = "Aplicado com " + erros.Count + " erro(s).";
                UIMessageBox.ShowWarning("Aplicado com " + erros.Count + " erro(s):\n" + string.Join("\n", erros));
            }
        }

        // Reiniciar Explorer
        private async void uiButton9_Click(object? sender, EventArgs e)
        {
            uiButton9.Enabled = false;
            lblStatusConfig.Text = "Reiniciando o Explorer...";

            try
            {
                foreach (var p in System.Diagnostics.Process.GetProcessesByName("explorer"))
                {
                    try { p.Kill(); } catch { }
                }

                await Task.Delay(1500);

                // o Windows normalmente reabre sozinho; se não abriu, abre aqui
                if (System.Diagnostics.Process.GetProcessesByName("explorer").Length == 0)
                    System.Diagnostics.Process.Start("explorer.exe");

                lblStatusConfig.Text = "Explorer reiniciado.";
            }
            catch (Exception ex)
            {
                lblStatusConfig.Text = "Falha ao reiniciar o Explorer: " + ex.Message;
            }
            finally
            {
                uiButton9.Enabled = true;
            }
        }

        // =================== Aba Remover apps ===================

        // AppIds marcados (continuam marcados mesmo ao filtrar/buscar)
        private readonly HashSet<string> _appsMarcados = new(StringComparer.OrdinalIgnoreCase);
        private HashSet<string>? _appsInstalados;
        private bool _atualizandoLista;

        private static Color CorDoNivel(NivelApp nivel) => nivel switch
        {
            NivelApp.Recomendado => ColorTranslator.FromHtml("#4ADE80"),
            NivelApp.Opcional => ColorTranslator.FromHtml("#FACC15"),
            _ => ColorTranslator.FromHtml("#F87171")
        };

        private void PreencherListaApps()
        {
            _atualizandoLista = true;
            lvApps.BeginUpdate();
            lvApps.Items.Clear();

            string busca = txtBuscaApps.Text.Trim();

            foreach (var app in RemocaoApps.Lista)
            {
                if (chkSoInstalados.Checked && _appsInstalados != null &&
                    !RemocaoApps.EstaInstalado(app, _appsInstalados))
                    continue;

                if (busca.Length > 0 &&
                    !app.Nome.Contains(busca, StringComparison.OrdinalIgnoreCase) &&
                    !app.Descricao.Contains(busca, StringComparison.OrdinalIgnoreCase) &&
                    !app.AppId.Contains(busca, StringComparison.OrdinalIgnoreCase))
                    continue;

                var item = new ListViewItem(app.Nome)
                {
                    Tag = app,
                    ForeColor = CorDoNivel(app.Nivel),
                    Checked = _appsMarcados.Contains(app.AppId)
                };
                item.SubItems.Add(app.Descricao);
                item.SubItems.Add(app.AppId);
                lvApps.Items.Add(item);
            }

            lvApps.EndUpdate();
            _atualizandoLista = false;
            AtualizarContagemApps();
        }

        private void AtualizarContagemApps()
        {
            lblContagemApps.Text = _appsMarcados.Count + " app(s) selecionado(s) para remoção";
        }

        private void lvApps_ItemChecked(object? sender, ItemCheckedEventArgs e)
        {
            if (_atualizandoLista || e.Item.Tag is not AppRemovivel app)
                return;

            if (e.Item.Checked)
                _appsMarcados.Add(app.AppId);
            else
                _appsMarcados.Remove(app.AppId);

            AtualizarContagemApps();
        }

        private void txtBuscaApps_TextChanged(object? sender, EventArgs e)
        {
            PreencherListaApps();
        }

        private async void chkSoInstalados_CheckedChanged(object? sender, EventArgs e)
        {
            if (chkSoInstalados.Checked && _appsInstalados == null)
            {
                chkSoInstalados.Enabled = false;
                lblStatusRemocao.Text = "Verificando apps instalados...";

                var instalados = await Task.Run(RemocaoApps.ObterInstalados);

                chkSoInstalados.Enabled = true;

                if (instalados.Count == 0)
                {
                    lblStatusRemocao.Text = "Não foi possível listar os apps instalados.";
                    UIMessageBox.ShowWarning("Não foi possível listar os apps instalados.");
                    chkSoInstalados.Checked = false; // volta a lista completa
                    return;
                }

                _appsInstalados = instalados;
                lblStatusRemocao.Text = "Pronto.";
            }

            PreencherListaApps();
        }

        // Recomendados (marca todos os verdes)
        private void uiButton10_Click(object? sender, EventArgs e)
        {
            foreach (var app in RemocaoApps.Lista)
            {
                if (app.Nivel != NivelApp.Recomendado)
                    continue;

                if (chkSoInstalados.Checked && _appsInstalados != null &&
                    !RemocaoApps.EstaInstalado(app, _appsInstalados))
                    continue;

                _appsMarcados.Add(app.AppId);
            }

            PreencherListaApps();
        }

        // Limpar seleção
        private void uiButton11_Click(object? sender, EventArgs e)
        {
            _appsMarcados.Clear();
            PreencherListaApps();
        }

        // Remover selecionados
        private async void uiButton12_Click(object? sender, EventArgs e)
        {
            var selecionados = RemocaoApps.Lista.Where(a => _appsMarcados.Contains(a.AppId)).ToList();

            if (selecionados.Count == 0)
            {
                UIMessageBox.ShowWarning("Marque pelo menos um aplicativo.");
                return;
            }

            if (!EhAdministrador())
            {
                UIMessageBox.ShowError("Execute o programa como Administrador.");
                return;
            }

            int perigosos = selecionados.Count(a => a.Nivel == NivelApp.NaoRecomendado);
            string pergunta = "Remover " + selecionados.Count + " aplicativo(s)?";
            if (perigosos > 0)
                pergunta += "\n\nATENÇÃO: " + perigosos + " item(ns) marcado(s) como NÃO recomendado(s) (vermelho). " +
                            "Removê-los pode quebrar recursos do Windows.";

            if (!UIMessageBox.ShowAsk(pergunta))
                return;

            uiButton10.Enabled = false;
            uiButton11.Enabled = false;
            uiButton12.Enabled = false;
            lvApps.Enabled = false;
            txtBuscaApps.Enabled = false;
            chkSoInstalados.Enabled = false;

            progressBarRemocao.Maximum = selecionados.Count;
            progressBarRemocao.Value = 0;

            var falhas = new List<string>();

            for (int i = 0; i < selecionados.Count; i++)
            {
                var app = selecionados[i];
                lblStatusRemocao.Text = "Removendo " + app.Nome + " (" + (i + 1) + "/" + selecionados.Count + ")...";

                var resultado = await RemocaoApps.RemoverAsync(app);

                if (resultado.Sucesso)
                    _appsMarcados.Remove(app.AppId);
                else
                    falhas.Add(app.Nome + ": " + resultado.Mensagem);

                progressBarRemocao.Value = i + 1;
            }

            // atualiza a lista de instalados para refletir o que saiu
            if (chkSoInstalados.Checked)
            {
                lblStatusRemocao.Text = "Atualizando a lista...";
                var instalados = await Task.Run(RemocaoApps.ObterInstalados);
                _appsInstalados = instalados.Count > 0 ? instalados : null;
            }
            else
            {
                _appsInstalados = null;
            }

            PreencherListaApps();

            uiButton10.Enabled = true;
            uiButton11.Enabled = true;
            uiButton12.Enabled = true;
            lvApps.Enabled = true;
            txtBuscaApps.Enabled = true;
            chkSoInstalados.Enabled = true;

            if (falhas.Count == 0)
            {
                lblStatusRemocao.Text = "Todos os apps selecionados foram removidos.";
                UIMessageBox.ShowSuccess("Remoção concluída!");
            }
            else
            {
                lblStatusRemocao.Text = "Concluído com " + falhas.Count + " falha(s).";
                UIMessageBox.ShowWarning("Falha em " + falhas.Count + " aplicativo(s):\n" + string.Join("\n", falhas));
            }
        }

        // =================== Aba Tweaks avançados ===================

        // Abre o Form2 na mesma posição e esconde este formulário.
        // O Form2 reabre o Form1 pelo botão "Voltar".
        private void uiButton13_Click(object? sender, EventArgs e)
        {
            var f2 = new Form2 { Principal = this };
            f2.StartPosition = FormStartPosition.Manual;
            f2.Location = Location;
            f2.Show();
            Hide();
        }
    }
}