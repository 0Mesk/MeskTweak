﻿using System.Diagnostics;
using System.Text;

namespace MeskTweaks
{
    public enum NivelApp
    {
        Recomendado,
        Opcional,
        NaoRecomendado
    }

    public sealed record AppRemovivel(string Nome, string Descricao, string AppId, NivelApp Nivel);

    /// <summary>
    /// Lista de apps removíveis do Windows 11 e a lógica para listar os instalados e remover.
    /// </summary>
    public static class RemocaoApps
    {
        private const NivelApp Rec = NivelApp.Recomendado;
        private const NivelApp Opc = NivelApp.Opcional;
        private const NivelApp Nao = NivelApp.NaoRecomendado;

        // AppId com "*" no final = prefixo (IDs que apareciam cortados na lista original).
        // AppId com vírgula = mais de um nome de pacote para o mesmo app.
        public static readonly IReadOnlyList<AppRemovivel> Lista = new List<AppRemovivel>
        {
            new("3D Builder", "Modelagem 3D básica", "Microsoft.3DBuilder", Rec),
            new("3D Viewer", "Visualizador de modelos 3D", "Microsoft.Microsoft3DViewer", Rec),
            new("ACG Media Player", "Player de mídia", "ACGMediaPlayer", Rec),
            new("Actipro Software", "Componentes de interface, geralmente instalados por fabricantes (OEM)", "ActiproSoftwareLLC", Rec),
            new("Adobe Photoshop Express", "Editor de fotos básico da Adobe", "AdobeSystemsIncorporated.AdobePhotosh*", Rec),
            new("Alarms & Clock", "Alarmes e relógio", "Microsoft.WindowsAlarms", Rec),
            new("Amazon", "App de compras da Amazon", "Amazon.com.Amazon", Rec),
            new("Asphalt 8", "Jogo de corrida", "Asphalt8Airborne", Rec),
            new("Autodesk SketchBook", "App de desenho e esboço", "AutodeskSketchBook", Rec),
            new("Bing Finance", "Notícias e acompanhamento financeiro via Bing (descontinuado)", "Microsoft.BingFinance", Rec),
            new("Bing Food And Drink", "Receitas e notícias de culinária via Bing (descontinuado)", "Microsoft.BingFoodAndDrink", Rec),
            new("Bing Health And Fitness", "Saúde e fitness via Bing (descontinuado)", "Microsoft.BingHealthAndFitness", Rec),
            new("Bing News", "Agregador de notícias via Bing (substituído pelo Microsoft News/Iniciar)", "Microsoft.BingNews", Rec),
            new("Bing Search", "Pesquisa web do Bing (integra com a pesquisa do Windows)", "Microsoft.BingSearch", Opc),
            new("Bing Sports", "Notícias e placares de esportes via Bing (descontinuado)", "Microsoft.BingSports", Rec),
            new("Bing Translator", "Serviço de tradução via Bing", "Microsoft.BingTranslator", Rec),
            new("Bing Travel", "Planejamento de viagens e notícias via Bing (descontinuado)", "Microsoft.BingTravel", Rec),
            new("Bing Weather", "Previsão do tempo via Bing", "Microsoft.BingWeather", Rec),
            new("Bubble Witch 3", "Jogo de quebra-cabeça da King", "king.com.BubbleWitch3Saga", Rec),
            new("Caesars Slots", "Jogo de caça-níquel de cassino", "CaesarsSlotsFreeCasino", Rec),
            new("Calculator", "Calculadora", "Microsoft.WindowsCalculator", Opc),
            new("Camera", "App de câmera para webcams e câmeras conectadas", "Microsoft.WindowsCamera", Opc),
            new("Candy Crush Saga", "Jogo de quebra-cabeça da King", "king.com.CandyCrushSaga", Rec),
            new("Candy Crush Soda", "Jogo de quebra-cabeça da King", "king.com.CandyCrushSodaSaga", Rec),
            new("Clipchamp", "Editor de vídeo da Microsoft", "Clipchamp.Clipchamp", Rec),
            new("Cooking Fever", "Jogo de simulação de restaurante", "COOKINGFEVER", Rec),
            new("Copilot+ AI Hub", "Hub de IA do Copilot+ (Windows 11 24H2+)", "Microsoft.Windows.AIHub", Rec),
            new("Cortana", "Assistente de voz da Microsoft (descontinuado)", "Microsoft.549981C3F5F10", Rec),
            new("Cross Device Experience", "Integração com celular no Explorer, Câmera e mais (parte do Phone Link)", "MicrosoftWindows.CrossDevice", Opc),
            new("CyberLink Media Suite", "Pacote multimídia (geralmente instalado por fabricantes)", "CyberLinkMediaSuiteEssentials", Rec),

            new("Dell Digital Delivery Services", "Software Dell para entregar programas comprados com o PC", "DellInc.DellDigitalDelivery", Opc),
            new("Dell Mobile Connect", "App Dell para conectar celular Android/iOS ao PC (substituído pelo Phone Link)", "DellInc.DellMobileConnect", Opc),
            new("Dell SupportAssist", "Ferramenta Dell de suporte, diagnóstico e atualização", "DellInc.DellSupportAssistforPCs", Opc),
            new("Dev Home", "Painel e configuração de ferramentas para desenvolvedores (descontinuado)", "Microsoft.Windows.DevHome", Rec),
            new("Disney Magic Kingdoms", "Jogo de construção de parque temático da Disney", "DisneyMagicKingdoms", Rec),
            new("Disney+", "App de streaming Disney+", "Disney.37853FC22B2CE", Rec),
            new("Drawboard PDF", "Visualização e anotação de PDF, focado em caneta", "DrawboardPDF", Rec),
            new("Duolingo", "App de aprendizado de idiomas", "Duolingo-LearnLanguagesforFree", Rec),
            new("Eclipse Manager", "Software de fabricante (OEM), p. ex. para ajustes de tela", "EclipseManager", Rec),
            new("Facebook", "App de rede social Facebook", "FACEBOOK.FACEBOOK", Rec),
            new("Family Safety", "Segurança familiar: gerencia contas e configurações da família", "MicrosoftCorporationII.MicrosoftFamily", Rec),
            new("FarmVille 2", "Jogo de simulação de fazenda", "FarmVille2CountryEscape", Rec),
            new("Feedback Hub", "App para enviar feedback à Microsoft", "Microsoft.WindowsFeedbackHub", Rec),
            new("Flipboard", "Agregador de notícias e redes sociais em formato de revista", "Flipboard", Rec),
            new("Get Help", "Necessário para alguns solucionadores de problemas e suporte do Windows 11", "Microsoft.GetHelp", Nao),
            new("Get Started", "Dicas e guia inicial do Windows (não pode ser desinstalado no Windows 11)", "Microsoft.Getstarted", Rec),

            new("Hidden City", "Jogo de aventura de objetos escondidos", "HiddenCity", Rec),
            new("HP AI Experience Center", "Software HP, recursos de IA e suporte", "AD2F1837.HPAIExperienceCenter", Opc),
            new("HP Connected Music", "Software HP para música (possivelmente descontinuado)", "AD2F1837.HPConnectedMusic", Opc),
            new("HP Connected Photo", "Software HP para fotos, integrado ao Snapfish (possivelmente descontinuado)", "AD2F1837.HPConnectedPhotopoweredbyS*", Opc),
            new("HP Desktop Support Utilities", "Software HP com ferramentas de suporte", "AD2F1837.HPDesktopSupportUtilities", Opc),
            new("HP Easy Clean", "Software HP de limpeza e otimização do sistema", "AD2F1837.HPEasyClean", Opc),
            new("HP File Viewer", "Software HP para visualizar tipos de arquivo específicos", "AD2F1837.HPFileViewer", Opc),
            new("HP JumpStarts", "Software HP de tutoriais e acesso rápido a recursos HP", "AD2F1837.HPJumpStarts", Opc),
            new("HP PC Hardware Diagnostics", "Software HP de diagnóstico de hardware", "AD2F1837.HPPCHardwareDiagnosticsWind*", Opc),
            new("HP Power Manager", "Software HP de energia e bateria", "AD2F1837.HPPowerManager", Opc),
            new("HP Printer Control", "Software HP para gerenciar impressoras HP", "AD2F1837.HPPrinterControl", Opc),
            new("HP Privacy Settings", "Software HP para configurações de privacidade", "AD2F1837.HPPrivacySettings", Opc),
            new("HP QuickDrop", "Software HP para transferir arquivos entre dispositivos", "AD2F1837.HPQuickDrop", Opc),
            new("HP QuickTouch", "Software HP, possivelmente atalhos de toque", "AD2F1837.HPQuickTouch", Opc),
            new("HP Registration", "Software HP de registro do produto", "AD2F1837.HPRegistration", Opc),
            new("HP Support Assistant", "Software HP de suporte, atualizações e solução de problemas", "AD2F1837.HPSupportAssistant", Opc),
            new("HP Sure Shield AI", "Software HP de segurança, provavelmente proteção contra ameaças com IA", "AD2F1837.HPSureShieldAI", Opc),
            new("HP System Information", "Software HP que mostra informações do sistema", "AD2F1837.HPSystemInformation", Opc),
            new("HP Welcome", "Software HP de boas-vindas e configuração inicial", "AD2F1837.HPWelcome", Opc),
            new("HP WorkWell", "Software HP de bem-estar, lembretes de pausa e ergonomia", "AD2F1837.HPWorkWell", Opc),
            new("Hulu", "App de streaming Hulu", "HULULLC.HULUPLUS", Rec),
            new("iHeartRadio", "Rádio via internet", "iHeartRadio", Rec),
            new("Instagram", "App de rede social Instagram", "Facebook.Instagram", Rec),
            new("Lenovo Vantage", "Central Lenovo de ajustes, atualizações e suporte", "E046963F.LenovoCompanion", Opc),
            new("Lenovo Vantage Service", "Serviço em segundo plano do Lenovo Vantage", "LenovoCompanyLimited.LenovoVantageSer*", Opc),
            new("LG Monitor App", "Software LG para controlar o monitor (o Windows Update pode reinstalar se houver monitor LG)", "LGElectronics.LGMonitorApp", Opc),
            new("LinkedIn", "App de rede profissional LinkedIn", "LinkedInforWindows", Rec),
            new("Live Wallpaper", "App de papel de parede animado", "Sidia.LiveWallpaper", Rec),
            new("Mail & Calendar", "Pacote Email e Calendário (descontinuado)", "Microsoft.windowscommunicationsapps", Rec),
            new("March of Empires", "Jogo de estratégia", "MarchofEmpires", Rec),

            new("Media Player", "Player de mídia moderno (substituiu o Groove Music, toca áudio/vídeo local)", "Microsoft.ZuneMusic", Opc),
            new("Messaging", "App de mensagens, integrado ao Skype (praticamente descontinuado)", "Microsoft.Messaging", Rec),
            new("Microsoft 365 Companions", "Mini-apps de Calendário, Arquivos e Pessoas do Microsoft 365 (podem ser reinstalados pelo admin)", "Microsoft.M365Companions", Opc),
            new("Microsoft Copilot", "Assistente de IA integrado ao Windows", "XP9CXNGPPJ97XX, Microsoft.Copilot", Rec),
            new("Microsoft Journal", "Anotações otimizadas para caneta", "Microsoft.MicrosoftJournal", Rec),
            new("Microsoft News", "Agregador de notícias (substituiu o Bing News, agora parte do Iniciar)", "Microsoft.News", Rec),
            new("Microsoft PC Manager", "Ferramenta Microsoft de limpeza e otimização (muitas vezes pré-instalada)", "Microsoft.PCManager", Rec),
            new("Microsoft Store", "Loja da Microsoft. AVISO: não é fácil reinstalar se for removida!", "Microsoft.WindowsStore", Nao),
            new("Microsoft Teams (New)", "Novo Microsoft Teams (trabalho/escola ou pessoal)", "MSTeams", Rec),
            new("Microsoft Teams (Old)", "Microsoft Teams pessoal antigo (versão da Microsoft Store)", "MicrosoftTeams", Rec),
            new("Microsoft To Do", "App de lista de tarefas", "Microsoft.Todos", Rec),
            new("Mixed Reality Portal", "Portal para headsets de Realidade Mista do Windows", "Microsoft.MixedReality.Portal", Rec),
            new("Movies & TV", "Filmes e TV: alugar, comprar e reproduzir vídeos (agora \"Films & TV\")", "Microsoft.ZuneVideo", Rec),
            new("myHP", "Central HP com informações do dispositivo, suporte e serviços", "AD2F1837.myHP", Opc),
            new("Netflix", "App de streaming Netflix", "4DF9E0F8.Netflix", Rec),

            new("Network Speed Test", "Teste de velocidade da internet", "Microsoft.NetworkSpeedTest", Rec),
            new("Notepad", "Editor de texto Bloco de Notas", "Microsoft.WindowsNotepad", Opc),
            new("NYT Crossword", "Palavras cruzadas do New York Times", "NYTCrossword", Rec),
            new("Office Hub", "Hub para acessar apps e documentos do Office (precursor do app Microsoft 365)", "Microsoft.MicrosoftOfficeHub", Rec),
            new("One Calendar", "Agregador de calendários", "OneCalendar", Rec),
            new("One Connect", "Gerenciamento de operadora móvel (substituído por Planos Móveis)", "Microsoft.OneConnect", Rec),
            new("OneDrive", "Cliente de armazenamento em nuvem OneDrive", "Microsoft.OneDrive", Opc),
            new("OneNote", "Anotações digitais (versão UWP)", "Microsoft.Office.OneNote", Rec),
            new("Outlook for Windows", "Novo cliente de email Outlook para Windows", "Microsoft.OutlookForWindows", Opc),
            new("Paint", "Paint clássico (pintura 2D tradicional)", "Microsoft.Paint", Opc),
            new("Paint 3D", "Paint moderno com recursos 3D", "Microsoft.MSPaint", Opc),
            new("Pandora", "App de streaming de música Pandora", "PandoraMediaInc", Rec),
            new("People", "Necessário para o Email e Calendário (descontinuado)", "Microsoft.People", Rec),
            new("Phone Link", "Conecta celular Android/iOS ao PC", "Microsoft.YourPhone", Opc),
            new("Photos", "App padrão para ver e editar fotos", "Microsoft.Windows.Photos", Opc),
            new("Phototastic Collage", "Criação de colagens de fotos", "PhototasticCollage", Rec),

            new("PicsArt", "Edição de fotos e criação", "PicsArt-PhotoStudio", Rec),
            new("Polarr Photo Editor", "Edição de fotos (Academic Edition)", "PolarrPhotoEditorAcademicEdition", Rec),
            new("Power Automate", "Ferramenta de automação para desktop (RPA)", "Microsoft.PowerAutomateDesktop", Rec),
            new("Power BI", "Cliente de análise de dados empresariais", "Microsoft.MicrosoftPowerBIForWindows", Rec),
            new("Prime Video", "App de streaming Amazon Prime Video", "AmazonVideo.PrimeVideo", Rec),
            new("Print 3D", "Preparação para impressão 3D", "Microsoft.Print3D", Rec),
            new("Quick Assist", "Ferramenta de assistência remota", "MicrosoftCorporationII.QuickAssist", Rec),
            new("Remote Desktop", "Cliente de Área de Trabalho Remota", "Microsoft.RemoteDesktop", Opc),
            new("Royal Revolt", "Jogo de defesa de torre / estratégia", "flaregamesGmbH.RoyalRevolt", Rec),
            new("Skype (UWP)", "Skype, versão Plataforma Universal do Windows (descontinuado)", "Microsoft.SkypeApp", Rec),
            new("Sling TV", "App de TV ao vivo via streaming", "SlingTV", Rec),
            new("Snipping Tool", "Ferramenta de Captura (capturas de tela e anotações)", "Microsoft.ScreenSketch", Opc),
            new("Solitaire Collection", "Coleção de jogos de paciência", "Microsoft.MicrosoftSolitaireCollection", Rec),
            new("Sound Recorder", "Gravador de áudio básico", "Microsoft.WindowsSoundRecorder", Rec),

            new("Spotify", "App de streaming de música Spotify", "SpotifyAB.SpotifyMusic", Rec),
            new("Sticky Notes", "Notas adesivas digitais (descontinuado, substituído pelo OneNote)", "Microsoft.MicrosoftStickyNotes", Rec),
            new("Sway", "App de apresentações e narrativas", "Microsoft.Office.Sway", Rec),
            new("TikTok", "App de vídeos curtos TikTok", "BytedancePte.Ltd.TikTok", Rec),
            new("TuneIn Radio", "Rádio via internet", "TuneInRadio", Rec),
            new("Whiteboard", "Quadro branco digital colaborativo", "Microsoft.Whiteboard", Opc),
            new("Widgets Experience", "Este app alimenta o Feed dos Widgets do Windows", "Microsoft.StartExperiencesApp", Opc),
            new("Widgets Platform Runtime", "Runtime necessário para os Widgets do Windows funcionarem", "Microsoft.WidgetsPlatformRuntime", Opc),
            new("Windows Maps", "App de mapas e navegação", "Microsoft.WindowsMaps", Rec),
            new("Windows Terminal", "Terminal padrão do Windows 11 (Prompt, PowerShell, WSL). AVISO: não remova se abriu o Win11Debloat por ele", "Microsoft.WindowsTerminal", Nao),
            new("Windows Web Experience Pack", "Entrega e atualiza recursos como os Widgets pela Microsoft Store", "MicrosoftWindows.Client.WebExperience", Opc),
            new("WinZip", "Compactação e extração de arquivos (versão UWP)", "WinZipUniversal", Rec),
            new("Xbox Console Companion", "Antigo app Xbox Console Companion (descontinuado)", "Microsoft.XboxApp", Rec),
            new("Xbox Game Overlay", "Sobreposição de jogo, necessária/útil para alguns jogos (parte da Xbox Game Bar)", "Microsoft.XboxGameOverlay", Opc),
            new("Xbox Gaming App", "App Xbox moderno, necessário para instalar alguns jogos de PC", "Microsoft.GamingApp", Opc),
            new("Xbox Gaming Overlay", "Sobreposição de jogo, necessária/útil para alguns jogos (parte da Xbox Game Bar)", "Microsoft.XboxGamingOverlay", Opc),
            new("Xbox Identity Provider", "Estrutura de login Xbox, necessária para alguns jogos e serviços Xbox", "Microsoft.XboxIdentityProvider", Nao),
            new("Xbox Speech To Text", "Recurso de acessibilidade necessário para alguns jogos. AVISO: não é fácil reinstalar!", "Microsoft.XboxSpeechToTextOverlay", Nao),
            new("Xbox TCUI Framework", "Estrutura de interface, parece ser necessária para a Microsoft Store, Fotos e alguns jogos", "Microsoft.Xbox.TCUI", Nao),
        };

        /// <summary>Divide o AppId em um ou mais nomes de pacote.</summary>
        private static IEnumerable<string> Ids(AppRemovivel app) =>
            app.AppId.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        /// <summary>Confere se o app está na lista de pacotes instalados.</summary>
        public static bool EstaInstalado(AppRemovivel app, HashSet<string> instalados)
        {
            foreach (var id in Ids(app))
            {
                if (id.EndsWith('*'))
                {
                    string prefixo = id.TrimEnd('*');
                    if (instalados.Any(n => n.StartsWith(prefixo, StringComparison.OrdinalIgnoreCase)))
                        return true;
                }
                else if (instalados.Contains(id))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>Lista os nomes de todos os pacotes (Appx) instalados no PC.</summary>
        public static HashSet<string> ObterInstalados()
        {
            var nomes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            try
            {
                var (saida, _) = ExecutarPowerShellAsync(
                    "$ProgressPreference='SilentlyContinue'; " +
                    "Get-AppxPackage -AllUsers | Select-Object -ExpandProperty Name").GetAwaiter().GetResult();

                foreach (var linha in saida.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                    nomes.Add(linha);
            }
            catch
            {
                // devolve vazio; quem chamou trata
            }

            return nomes;
        }

        /// <summary>Remove o app para todos os usuários (e do pacote de provisionamento). Precisa de Administrador.</summary>
        public static async Task<(bool Sucesso, string Mensagem)> RemoverAsync(AppRemovivel app)
        {
            try
            {
                var sb = new StringBuilder();
                sb.AppendLine("$ProgressPreference='SilentlyContinue'; $ErrorActionPreference='SilentlyContinue'");
                sb.AppendLine("$restantes = 0");

                foreach (var id in Ids(app))
                {
                    sb.AppendLine("$n = '" + id.Replace("'", "''") + "'");
                    sb.AppendLine("Get-AppxPackage -AllUsers -Name $n | ForEach-Object { Remove-AppxPackage -Package $_.PackageFullName -AllUsers }");
                    sb.AppendLine("Get-AppxProvisionedPackage -Online | Where-Object { $_.DisplayName -like $n } | ForEach-Object { Remove-AppxProvisionedPackage -Online -PackageName $_.PackageName | Out-Null }");
                    sb.AppendLine("$restantes += @(Get-AppxPackage -AllUsers -Name $n).Count");
                }

                sb.AppendLine("Write-Output ('RESTANTES=' + $restantes)");

                var (saida, erro) = await ExecutarPowerShellAsync(sb.ToString());

                var linha = saida
                    .Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                    .FirstOrDefault(l => l.StartsWith("RESTANTES="));

                if (linha == null)
                    return (false, string.IsNullOrWhiteSpace(erro) ? "O PowerShell não retornou resultado." : erro.Trim());

                if (linha == "RESTANTES=0")
                    return (true, "Removido.");

                return (false, "continua instalado (o Windows bloqueou ou o app é protegido).");
            }
            catch (Exception ex)
            {
                return (false, ex.Message);
            }
        }

        private static async Task<(string Saida, string Erro)> ExecutarPowerShellAsync(string script)
        {
            // -EncodedCommand evita problemas com aspas e caracteres especiais
            string b64 = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));

            var psi = new ProcessStartInfo("powershell.exe",
                "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + b64)
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };

            using var p = Process.Start(psi)
                ?? throw new InvalidOperationException("Não foi possível iniciar o PowerShell.");

            var tarefaSaida = p.StandardOutput.ReadToEndAsync();
            var tarefaErro = p.StandardError.ReadToEndAsync();
            await p.WaitForExitAsync();

            return (await tarefaSaida, await tarefaErro);
        }
    }
}