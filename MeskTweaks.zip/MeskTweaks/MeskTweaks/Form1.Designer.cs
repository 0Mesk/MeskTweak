#nullable disable
namespace MeskTweaks
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer do Windows Forms

        private void InitializeComponent()
        {
            uiButton1 = new Sunny.UI.UIButton();
            uiTabControlMenu1 = new Sunny.UI.UITabControlMenu();
            tabPage1 = new TabPage();
            lblStatus = new Label();
            lblDescricao = new Label();
            lblTitulo = new Label();
            uiButton2 = new Sunny.UI.UIButton();
            tabPage2 = new TabPage();
            lblApps = new Label();
            checkedListBox1 = new CheckedListBox();
            uiButton3 = new Sunny.UI.UIButton();
            uiButton4 = new Sunny.UI.UIButton();
            progressBar1 = new ProgressBar();
            lblStatusApps = new Label();
            tabPage3 = new TabPage();
            lblStatusFerramentas = new Label();
            uiButton5 = new Sunny.UI.UIButton();
            lblDescFerramentas = new Label();
            lblFerramentas = new Label();
            tabPage5 = new TabPage();
            lblConfig = new Label();
            lblDescConfig = new Label();
            chkTemaEscuro = new CheckBox();
            chkTransparencia = new CheckBox();
            chkNotificacoes = new CheckBox();
            chkSugestoes = new CheckBox();
            chkModoJogo = new CheckBox();
            chkExtensoes = new CheckBox();
            chkOcultos = new CheckBox();
            chkMenuClassico = new CheckBox();
            chkBarraEsquerda = new CheckBox();
            chkWidgets = new CheckBox();
            chkBusca = new CheckBox();
            chkVisaoTarefas = new CheckBox();
            uiButton7 = new Sunny.UI.UIButton();
            uiButton8 = new Sunny.UI.UIButton();
            uiButton9 = new Sunny.UI.UIButton();
            lblStatusConfig = new Label();
            tabPage6 = new TabPage();
            lblRemover = new Label();
            uiButton10 = new Sunny.UI.UIButton();
            uiButton11 = new Sunny.UI.UIButton();
            txtBuscaApps = new TextBox();
            chkSoInstalados = new CheckBox();
            lvApps = new ListView();
            colNomeApp = new ColumnHeader();
            colDescApp = new ColumnHeader();
            colIdApp = new ColumnHeader();
            lblContagemApps = new Label();
            lblLegendaApps = new Label();
            uiButton12 = new Sunny.UI.UIButton();
            progressBarRemocao = new ProgressBar();
            lblStatusRemocao = new Label();
            tabPage7 = new TabPage();
            lblAvancado = new Label();
            lblDescAvancado = new Label();
            uiButton13 = new Sunny.UI.UIButton();
            uiTabControlMenu1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            tabPage3.SuspendLayout();
            tabPage5.SuspendLayout();
            tabPage6.SuspendLayout();
            tabPage7.SuspendLayout();
            SuspendLayout();
            // 
            // uiButton1
            // 
            uiButton1.Cursor = Cursors.Hand;
            uiButton1.Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold);
            uiButton1.Location = new Point(54, 220);
            uiButton1.MinimumSize = new Size(1, 1);
            uiButton1.Name = "uiButton1";
            uiButton1.Size = new Size(300, 60);
            uiButton1.TabIndex = 0;
            uiButton1.Text = "Desativar tudo";
            uiButton1.TipsFont = new Font("Microsoft Sans Serif", 9F);
            uiButton1.Click += uiButton1_Click;
            // 
            // uiTabControlMenu1
            // 
            uiTabControlMenu1.Alignment = TabAlignment.Left;
            uiTabControlMenu1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            uiTabControlMenu1.Controls.Add(tabPage1);
            uiTabControlMenu1.Controls.Add(tabPage2);
            uiTabControlMenu1.Controls.Add(tabPage3);
            uiTabControlMenu1.Controls.Add(tabPage5);
            uiTabControlMenu1.Controls.Add(tabPage6);
            uiTabControlMenu1.Controls.Add(tabPage7);
            uiTabControlMenu1.DrawMode = TabDrawMode.OwnerDrawFixed;
            uiTabControlMenu1.Font = new Font("Segoe UI", 11F);
            uiTabControlMenu1.ItemSize = new Size(180, 56);
            uiTabControlMenu1.Location = new Point(0, 35);
            uiTabControlMenu1.Multiline = true;
            uiTabControlMenu1.Name = "uiTabControlMenu1";
            uiTabControlMenu1.SelectedIndex = 0;
            uiTabControlMenu1.Size = new Size(1000, 605);
            uiTabControlMenu1.SizeMode = TabSizeMode.Fixed;
            uiTabControlMenu1.TabIndex = 1;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(lblStatus);
            tabPage1.Controls.Add(lblDescricao);
            tabPage1.Controls.Add(lblTitulo);
            tabPage1.Controls.Add(uiButton2);
            tabPage1.Controls.Add(uiButton1);
            tabPage1.Location = new Point(181, 0);
            tabPage1.Name = "tabPage1";
            tabPage1.Size = new Size(819, 605);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Privacidade";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.BackColor = Color.Transparent;
            lblTitulo.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblTitulo.ForeColor = Color.FromArgb(243, 232, 255);
            lblTitulo.Location = new Point(50, 40);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(380, 45);
            lblTitulo.TabIndex = 2;
            lblTitulo.Text = "Privacidade e Telemetria";
            // 
            // lblDescricao
            // 
            lblDescricao.BackColor = Color.Transparent;
            lblDescricao.Font = new Font("Segoe UI", 11F);
            lblDescricao.ForeColor = Color.FromArgb(159, 143, 196);
            lblDescricao.Location = new Point(54, 105);
            lblDescricao.Name = "lblDescricao";
            lblDescricao.Size = new Size(700, 90);
            lblDescricao.TabIndex = 3;
            lblDescricao.Text = "Desativa de verdade a coleta de dados, telemetria, localização, Cortana, feed de atividades e outras funções do Windows (via políticas do sistema). Use \"Voltar ao padrão\" para desfazer tudo.";
            // 
            // uiButton2
            // 
            uiButton2.Cursor = Cursors.Hand;
            uiButton2.Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold);
            uiButton2.Location = new Point(374, 220);
            uiButton2.MinimumSize = new Size(1, 1);
            uiButton2.Name = "uiButton2";
            uiButton2.Size = new Size(380, 60);
            uiButton2.TabIndex = 1;
            uiButton2.Text = "Voltar ao padrão do Windows";
            uiButton2.TipsFont = new Font("Microsoft Sans Serif", 9F);
            uiButton2.Click += uiButton2_Click;
            // 
            // lblStatus
            // 
            lblStatus.BackColor = Color.Transparent;
            lblStatus.Font = new Font("Segoe UI", 11F);
            lblStatus.ForeColor = Color.FromArgb(192, 132, 252);
            lblStatus.Location = new Point(54, 305);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(700, 60);
            lblStatus.TabIndex = 4;
            lblStatus.Text = "Pronto. Execute como Administrador.";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(lblStatusApps);
            tabPage2.Controls.Add(progressBar1);
            tabPage2.Controls.Add(uiButton4);
            tabPage2.Controls.Add(uiButton3);
            tabPage2.Controls.Add(checkedListBox1);
            tabPage2.Controls.Add(lblApps);
            tabPage2.Location = new Point(181, 0);
            tabPage2.Name = "tabPage2";
            tabPage2.Size = new Size(819, 605);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Aplicativos";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblApps
            // 
            lblApps.AutoSize = true;
            lblApps.BackColor = Color.Transparent;
            lblApps.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblApps.ForeColor = Color.FromArgb(243, 232, 255);
            lblApps.Location = new Point(50, 24);
            lblApps.Name = "lblApps";
            lblApps.Size = new Size(260, 45);
            lblApps.TabIndex = 0;
            lblApps.Text = "Aplicativos úteis";
            // 
            // checkedListBox1
            // 
            checkedListBox1.BorderStyle = BorderStyle.None;
            checkedListBox1.CheckOnClick = true;
            checkedListBox1.Font = new Font("Segoe UI", 12F);
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Location = new Point(54, 86);
            checkedListBox1.Name = "checkedListBox1";
            checkedListBox1.Size = new Size(700, 300);
            checkedListBox1.TabIndex = 1;
            // 
            // uiButton3
            // 
            uiButton3.Cursor = Cursors.Hand;
            uiButton3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            uiButton3.Location = new Point(54, 405);
            uiButton3.MinimumSize = new Size(1, 1);
            uiButton3.Name = "uiButton3";
            uiButton3.Size = new Size(220, 52);
            uiButton3.TabIndex = 2;
            uiButton3.Text = "Selecionar todos";
            uiButton3.TipsFont = new Font("Microsoft Sans Serif", 9F);
            uiButton3.Click += uiButton3_Click;
            // 
            // uiButton4
            // 
            uiButton4.Cursor = Cursors.Hand;
            uiButton4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            uiButton4.Location = new Point(290, 405);
            uiButton4.MinimumSize = new Size(1, 1);
            uiButton4.Name = "uiButton4";
            uiButton4.Size = new Size(464, 52);
            uiButton4.TabIndex = 3;
            uiButton4.Text = "Instalar selecionados";
            uiButton4.TipsFont = new Font("Microsoft Sans Serif", 9F);
            uiButton4.Click += uiButton4_Click;
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(54, 478);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(700, 10);
            progressBar1.TabIndex = 4;
            // 
            // lblStatusApps
            // 
            lblStatusApps.BackColor = Color.Transparent;
            lblStatusApps.Font = new Font("Segoe UI", 11F);
            lblStatusApps.ForeColor = Color.FromArgb(192, 132, 252);
            lblStatusApps.Location = new Point(54, 498);
            lblStatusApps.Name = "lblStatusApps";
            lblStatusApps.Size = new Size(700, 50);
            lblStatusApps.TabIndex = 5;
            lblStatusApps.Text = "Marque os aplicativos e clique em instalar (usa o winget).";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(lblStatusFerramentas);
            tabPage3.Controls.Add(uiButton5);
            tabPage3.Controls.Add(lblDescFerramentas);
            tabPage3.Controls.Add(lblFerramentas);
            tabPage3.Location = new Point(181, 0);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(819, 605);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Ferramentas";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // lblFerramentas
            // 
            lblFerramentas.AutoSize = true;
            lblFerramentas.BackColor = Color.Transparent;
            lblFerramentas.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblFerramentas.ForeColor = Color.FromArgb(243, 232, 255);
            lblFerramentas.Location = new Point(50, 40);
            lblFerramentas.Name = "lblFerramentas";
            lblFerramentas.Size = new Size(200, 45);
            lblFerramentas.TabIndex = 0;
            lblFerramentas.Text = "Ferramentas";
            // 
            // lblDescFerramentas
            // 
            lblDescFerramentas.BackColor = Color.Transparent;
            lblDescFerramentas.Font = new Font("Segoe UI", 11F);
            lblDescFerramentas.ForeColor = Color.FromArgb(159, 143, 196);
            lblDescFerramentas.Location = new Point(54, 105);
            lblDescFerramentas.Name = "lblDescFerramentas";
            lblDescFerramentas.Size = new Size(700, 70);
            lblDescFerramentas.TabIndex = 1;
            lblDescFerramentas.Text = "Baixa, extrai em uma pasta temporária e executa o DControl, direto do repositório oficial do MeskTweaks.";
            // 
            // uiButton5
            // 
            uiButton5.Cursor = Cursors.Hand;
            uiButton5.Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold);
            uiButton5.Location = new Point(54, 195);
            uiButton5.MinimumSize = new Size(1, 1);
            uiButton5.Name = "uiButton5";
            uiButton5.Size = new Size(340, 60);
            uiButton5.TabIndex = 2;
            uiButton5.Text = "Baixar e abrir DControl";
            uiButton5.TipsFont = new Font("Microsoft Sans Serif", 9F);
            uiButton5.Click += uiButton5_Click;
            // 
            // lblStatusFerramentas
            // 
            lblStatusFerramentas.BackColor = Color.Transparent;
            lblStatusFerramentas.Font = new Font("Segoe UI", 11F);
            lblStatusFerramentas.ForeColor = Color.FromArgb(192, 132, 252);
            lblStatusFerramentas.Location = new Point(54, 280);
            lblStatusFerramentas.Name = "lblStatusFerramentas";
            lblStatusFerramentas.Size = new Size(700, 60);
            lblStatusFerramentas.TabIndex = 3;
            lblStatusFerramentas.Text = "Pronto.";
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(lblStatusConfig);
            tabPage5.Controls.Add(uiButton9);
            tabPage5.Controls.Add(uiButton8);
            tabPage5.Controls.Add(uiButton7);
            tabPage5.Controls.Add(chkVisaoTarefas);
            tabPage5.Controls.Add(chkBusca);
            tabPage5.Controls.Add(chkWidgets);
            tabPage5.Controls.Add(chkBarraEsquerda);
            tabPage5.Controls.Add(chkMenuClassico);
            tabPage5.Controls.Add(chkOcultos);
            tabPage5.Controls.Add(chkExtensoes);
            tabPage5.Controls.Add(chkModoJogo);
            tabPage5.Controls.Add(chkSugestoes);
            tabPage5.Controls.Add(chkNotificacoes);
            tabPage5.Controls.Add(chkTransparencia);
            tabPage5.Controls.Add(chkTemaEscuro);
            tabPage5.Controls.Add(lblDescConfig);
            tabPage5.Controls.Add(lblConfig);
            tabPage5.Location = new Point(181, 0);
            tabPage5.Name = "tabPage5";
            tabPage5.Size = new Size(819, 605);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "Configurações";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // lblConfig
            // 
            lblConfig.AutoSize = true;
            lblConfig.BackColor = Color.Transparent;
            lblConfig.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblConfig.ForeColor = Color.FromArgb(243, 232, 255);
            lblConfig.Location = new Point(50, 20);
            lblConfig.Name = "lblConfig";
            lblConfig.Size = new Size(260, 45);
            lblConfig.TabIndex = 0;
            lblConfig.Text = "Configurações";
            // 
            // lblDescConfig
            // 
            lblDescConfig.BackColor = Color.Transparent;
            lblDescConfig.Font = new Font("Segoe UI", 10F);
            lblDescConfig.ForeColor = Color.FromArgb(159, 143, 196);
            lblDescConfig.Location = new Point(54, 70);
            lblDescConfig.Name = "lblDescConfig";
            lblDescConfig.Size = new Size(700, 44);
            lblDescConfig.TabIndex = 1;
            lblDescConfig.Text = "Marcado = ligado, desmarcado = desligado. Clique em \"Aplicar configurações\" para gravar. Menu clássico, barra de tarefas e widgets só mudam após reiniciar o Explorer.";
            // 
            // chkTemaEscuro
            // 
            chkTemaEscuro.AutoSize = false;
            chkTemaEscuro.BackColor = Color.Transparent;
            chkTemaEscuro.Cursor = Cursors.Hand;
            chkTemaEscuro.Font = new Font("Segoe UI", 11F);
            chkTemaEscuro.ForeColor = Color.FromArgb(243, 232, 255);
            chkTemaEscuro.Location = new Point(54, 130);
            chkTemaEscuro.Name = "chkTemaEscuro";
            chkTemaEscuro.Size = new Size(340, 36);
            chkTemaEscuro.TabIndex = 2;
            chkTemaEscuro.Text = "Tema escuro (apps e sistema)";
            chkTemaEscuro.UseVisualStyleBackColor = false;
            // 
            // chkTransparencia
            // 
            chkTransparencia.AutoSize = false;
            chkTransparencia.BackColor = Color.Transparent;
            chkTransparencia.Cursor = Cursors.Hand;
            chkTransparencia.Font = new Font("Segoe UI", 11F);
            chkTransparencia.ForeColor = Color.FromArgb(243, 232, 255);
            chkTransparencia.Location = new Point(54, 176);
            chkTransparencia.Name = "chkTransparencia";
            chkTransparencia.Size = new Size(340, 36);
            chkTransparencia.TabIndex = 3;
            chkTransparencia.Text = "Efeitos de transparência";
            chkTransparencia.UseVisualStyleBackColor = false;
            // 
            // chkNotificacoes
            // 
            chkNotificacoes.AutoSize = false;
            chkNotificacoes.BackColor = Color.Transparent;
            chkNotificacoes.Cursor = Cursors.Hand;
            chkNotificacoes.Font = new Font("Segoe UI", 11F);
            chkNotificacoes.ForeColor = Color.FromArgb(243, 232, 255);
            chkNotificacoes.Location = new Point(54, 222);
            chkNotificacoes.Name = "chkNotificacoes";
            chkNotificacoes.Size = new Size(340, 36);
            chkNotificacoes.TabIndex = 4;
            chkNotificacoes.Text = "Notificações do Windows";
            chkNotificacoes.UseVisualStyleBackColor = false;
            // 
            // chkSugestoes
            // 
            chkSugestoes.AutoSize = false;
            chkSugestoes.BackColor = Color.Transparent;
            chkSugestoes.Cursor = Cursors.Hand;
            chkSugestoes.Font = new Font("Segoe UI", 11F);
            chkSugestoes.ForeColor = Color.FromArgb(243, 232, 255);
            chkSugestoes.Location = new Point(54, 268);
            chkSugestoes.Name = "chkSugestoes";
            chkSugestoes.Size = new Size(340, 36);
            chkSugestoes.TabIndex = 5;
            chkSugestoes.Text = "Sugestões e anúncios do Windows";
            chkSugestoes.UseVisualStyleBackColor = false;
            // 
            // chkModoJogo
            // 
            chkModoJogo.AutoSize = false;
            chkModoJogo.BackColor = Color.Transparent;
            chkModoJogo.Cursor = Cursors.Hand;
            chkModoJogo.Font = new Font("Segoe UI", 11F);
            chkModoJogo.ForeColor = Color.FromArgb(243, 232, 255);
            chkModoJogo.Location = new Point(54, 314);
            chkModoJogo.Name = "chkModoJogo";
            chkModoJogo.Size = new Size(340, 36);
            chkModoJogo.TabIndex = 6;
            chkModoJogo.Text = "Modo de jogo";
            chkModoJogo.UseVisualStyleBackColor = false;
            // 
            // chkExtensoes
            // 
            chkExtensoes.AutoSize = false;
            chkExtensoes.BackColor = Color.Transparent;
            chkExtensoes.Cursor = Cursors.Hand;
            chkExtensoes.Font = new Font("Segoe UI", 11F);
            chkExtensoes.ForeColor = Color.FromArgb(243, 232, 255);
            chkExtensoes.Location = new Point(54, 360);
            chkExtensoes.Name = "chkExtensoes";
            chkExtensoes.Size = new Size(340, 36);
            chkExtensoes.TabIndex = 7;
            chkExtensoes.Text = "Mostrar extensões de arquivos";
            chkExtensoes.UseVisualStyleBackColor = false;
            // 
            // chkOcultos
            // 
            chkOcultos.AutoSize = false;
            chkOcultos.BackColor = Color.Transparent;
            chkOcultos.Cursor = Cursors.Hand;
            chkOcultos.Font = new Font("Segoe UI", 11F);
            chkOcultos.ForeColor = Color.FromArgb(243, 232, 255);
            chkOcultos.Location = new Point(424, 130);
            chkOcultos.Name = "chkOcultos";
            chkOcultos.Size = new Size(340, 36);
            chkOcultos.TabIndex = 8;
            chkOcultos.Text = "Mostrar arquivos ocultos";
            chkOcultos.UseVisualStyleBackColor = false;
            // 
            // chkMenuClassico
            // 
            chkMenuClassico.AutoSize = false;
            chkMenuClassico.BackColor = Color.Transparent;
            chkMenuClassico.Cursor = Cursors.Hand;
            chkMenuClassico.Font = new Font("Segoe UI", 11F);
            chkMenuClassico.ForeColor = Color.FromArgb(243, 232, 255);
            chkMenuClassico.Location = new Point(424, 176);
            chkMenuClassico.Name = "chkMenuClassico";
            chkMenuClassico.Size = new Size(340, 36);
            chkMenuClassico.TabIndex = 9;
            chkMenuClassico.Text = "Menu de contexto clássico";
            chkMenuClassico.UseVisualStyleBackColor = false;
            // 
            // chkBarraEsquerda
            // 
            chkBarraEsquerda.AutoSize = false;
            chkBarraEsquerda.BackColor = Color.Transparent;
            chkBarraEsquerda.Cursor = Cursors.Hand;
            chkBarraEsquerda.Font = new Font("Segoe UI", 11F);
            chkBarraEsquerda.ForeColor = Color.FromArgb(243, 232, 255);
            chkBarraEsquerda.Location = new Point(424, 222);
            chkBarraEsquerda.Name = "chkBarraEsquerda";
            chkBarraEsquerda.Size = new Size(340, 36);
            chkBarraEsquerda.TabIndex = 10;
            chkBarraEsquerda.Text = "Barra de tarefas à esquerda";
            chkBarraEsquerda.UseVisualStyleBackColor = false;
            // 
            // chkWidgets
            // 
            chkWidgets.AutoSize = false;
            chkWidgets.BackColor = Color.Transparent;
            chkWidgets.Cursor = Cursors.Hand;
            chkWidgets.Font = new Font("Segoe UI", 11F);
            chkWidgets.ForeColor = Color.FromArgb(243, 232, 255);
            chkWidgets.Location = new Point(424, 268);
            chkWidgets.Name = "chkWidgets";
            chkWidgets.Size = new Size(340, 36);
            chkWidgets.TabIndex = 11;
            chkWidgets.Text = "Widgets na barra de tarefas";
            chkWidgets.UseVisualStyleBackColor = false;
            // 
            // chkBusca
            // 
            chkBusca.AutoSize = false;
            chkBusca.BackColor = Color.Transparent;
            chkBusca.Cursor = Cursors.Hand;
            chkBusca.Font = new Font("Segoe UI", 11F);
            chkBusca.ForeColor = Color.FromArgb(243, 232, 255);
            chkBusca.Location = new Point(424, 314);
            chkBusca.Name = "chkBusca";
            chkBusca.Size = new Size(340, 36);
            chkBusca.TabIndex = 12;
            chkBusca.Text = "Pesquisa na barra de tarefas";
            chkBusca.UseVisualStyleBackColor = false;
            // 
            // chkVisaoTarefas
            // 
            chkVisaoTarefas.AutoSize = false;
            chkVisaoTarefas.BackColor = Color.Transparent;
            chkVisaoTarefas.Cursor = Cursors.Hand;
            chkVisaoTarefas.Font = new Font("Segoe UI", 11F);
            chkVisaoTarefas.ForeColor = Color.FromArgb(243, 232, 255);
            chkVisaoTarefas.Location = new Point(424, 360);
            chkVisaoTarefas.Name = "chkVisaoTarefas";
            chkVisaoTarefas.Size = new Size(340, 36);
            chkVisaoTarefas.TabIndex = 13;
            chkVisaoTarefas.Text = "Botão Visão de Tarefas";
            chkVisaoTarefas.UseVisualStyleBackColor = false;
            // 
            // uiButton7
            // 
            uiButton7.Cursor = Cursors.Hand;
            uiButton7.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            uiButton7.Location = new Point(54, 425);
            uiButton7.MinimumSize = new Size(1, 1);
            uiButton7.Name = "uiButton7";
            uiButton7.Size = new Size(260, 56);
            uiButton7.TabIndex = 14;
            uiButton7.Text = "Aplicar configurações";
            uiButton7.TipsFont = new Font("Microsoft Sans Serif", 9F);
            uiButton7.Click += uiButton7_Click;
            // 
            // uiButton8
            // 
            uiButton8.Cursor = Cursors.Hand;
            uiButton8.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            uiButton8.Location = new Point(330, 425);
            uiButton8.MinimumSize = new Size(1, 1);
            uiButton8.Name = "uiButton8";
            uiButton8.Size = new Size(220, 56);
            uiButton8.TabIndex = 15;
            uiButton8.Text = "Carregar atuais";
            uiButton8.TipsFont = new Font("Microsoft Sans Serif", 9F);
            uiButton8.Click += uiButton8_Click;
            // 
            // uiButton9
            // 
            uiButton9.Cursor = Cursors.Hand;
            uiButton9.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            uiButton9.Location = new Point(566, 425);
            uiButton9.MinimumSize = new Size(1, 1);
            uiButton9.Name = "uiButton9";
            uiButton9.Size = new Size(198, 56);
            uiButton9.TabIndex = 16;
            uiButton9.Text = "Reiniciar Explorer";
            uiButton9.TipsFont = new Font("Microsoft Sans Serif", 9F);
            uiButton9.Click += uiButton9_Click;
            // 
            // lblStatusConfig
            // 
            lblStatusConfig.BackColor = Color.Transparent;
            lblStatusConfig.Font = new Font("Segoe UI", 11F);
            lblStatusConfig.ForeColor = Color.FromArgb(192, 132, 252);
            lblStatusConfig.Location = new Point(54, 500);
            lblStatusConfig.Name = "lblStatusConfig";
            lblStatusConfig.Size = new Size(700, 60);
            lblStatusConfig.TabIndex = 17;
            lblStatusConfig.Text = "Pronto.";
            // 
            // tabPage6
            // 
            tabPage6.Controls.Add(lblStatusRemocao);
            tabPage6.Controls.Add(progressBarRemocao);
            tabPage6.Controls.Add(uiButton12);
            tabPage6.Controls.Add(lblLegendaApps);
            tabPage6.Controls.Add(lblContagemApps);
            tabPage6.Controls.Add(lvApps);
            tabPage6.Controls.Add(chkSoInstalados);
            tabPage6.Controls.Add(txtBuscaApps);
            tabPage6.Controls.Add(uiButton11);
            tabPage6.Controls.Add(uiButton10);
            tabPage6.Controls.Add(lblRemover);
            tabPage6.Location = new Point(181, 0);
            tabPage6.Name = "tabPage6";
            tabPage6.Size = new Size(819, 605);
            tabPage6.TabIndex = 5;
            tabPage6.Text = "Remover apps";
            tabPage6.UseVisualStyleBackColor = true;
            // 
            // lblRemover
            // 
            lblRemover.AutoSize = true;
            lblRemover.BackColor = Color.Transparent;
            lblRemover.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblRemover.ForeColor = Color.FromArgb(243, 232, 255);
            lblRemover.Location = new Point(50, 8);
            lblRemover.Name = "lblRemover";
            lblRemover.Size = new Size(260, 45);
            lblRemover.TabIndex = 0;
            lblRemover.Text = "Remover apps";
            // 
            // uiButton10
            // 
            uiButton10.Cursor = Cursors.Hand;
            uiButton10.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            uiButton10.Location = new Point(54, 64);
            uiButton10.MinimumSize = new Size(1, 1);
            uiButton10.Name = "uiButton10";
            uiButton10.Size = new Size(160, 40);
            uiButton10.TabIndex = 1;
            uiButton10.Text = "Recomendados";
            uiButton10.TipsFont = new Font("Microsoft Sans Serif", 9F);
            uiButton10.Click += uiButton10_Click;
            // 
            // uiButton11
            // 
            uiButton11.Cursor = Cursors.Hand;
            uiButton11.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            uiButton11.Location = new Point(224, 64);
            uiButton11.MinimumSize = new Size(1, 1);
            uiButton11.Name = "uiButton11";
            uiButton11.Size = new Size(160, 40);
            uiButton11.TabIndex = 2;
            uiButton11.Text = "Limpar seleção";
            uiButton11.TipsFont = new Font("Microsoft Sans Serif", 9F);
            uiButton11.Click += uiButton11_Click;
            // 
            // txtBuscaApps
            // 
            txtBuscaApps.BackColor = Color.FromArgb(21, 14, 38);
            txtBuscaApps.BorderStyle = BorderStyle.FixedSingle;
            txtBuscaApps.Font = new Font("Segoe UI", 11F);
            txtBuscaApps.ForeColor = Color.FromArgb(243, 232, 255);
            txtBuscaApps.Location = new Point(400, 70);
            txtBuscaApps.Name = "txtBuscaApps";
            txtBuscaApps.PlaceholderText = "Buscar apps...";
            txtBuscaApps.Size = new Size(220, 27);
            txtBuscaApps.TabIndex = 3;
            txtBuscaApps.TextChanged += txtBuscaApps_TextChanged;
            // 
            // chkSoInstalados
            // 
            chkSoInstalados.AutoSize = false;
            chkSoInstalados.BackColor = Color.Transparent;
            chkSoInstalados.Cursor = Cursors.Hand;
            chkSoInstalados.Font = new Font("Segoe UI", 10.5F);
            chkSoInstalados.ForeColor = Color.FromArgb(243, 232, 255);
            chkSoInstalados.Location = new Point(634, 68);
            chkSoInstalados.Name = "chkSoInstalados";
            chkSoInstalados.Size = new Size(160, 32);
            chkSoInstalados.TabIndex = 4;
            chkSoInstalados.Text = "Só instalados";
            chkSoInstalados.UseVisualStyleBackColor = false;
            chkSoInstalados.CheckedChanged += chkSoInstalados_CheckedChanged;
            // 
            // lvApps
            // 
            lvApps.BackColor = Color.FromArgb(21, 14, 38);
            lvApps.BorderStyle = BorderStyle.None;
            lvApps.CheckBoxes = true;
            lvApps.Columns.AddRange(new ColumnHeader[] { colNomeApp, colDescApp, colIdApp });
            lvApps.Font = new Font("Segoe UI", 10F);
            lvApps.ForeColor = Color.FromArgb(243, 232, 255);
            lvApps.FullRowSelect = true;
            lvApps.HideSelection = false;
            lvApps.Location = new Point(54, 114);
            lvApps.MultiSelect = false;
            lvApps.Name = "lvApps";
            lvApps.Size = new Size(740, 330);
            lvApps.TabIndex = 5;
            lvApps.UseCompatibleStateImageBehavior = false;
            lvApps.View = View.Details;
            lvApps.ItemChecked += lvApps_ItemChecked;
            // 
            // colNomeApp
            // 
            colNomeApp.Text = "Nome";
            colNomeApp.Width = 190;
            // 
            // colDescApp
            // 
            colDescApp.Text = "Descrição";
            colDescApp.Width = 340;
            // 
            // colIdApp
            // 
            colIdApp.Text = "App ID";
            colIdApp.Width = 190;
            // 
            // lblContagemApps
            // 
            lblContagemApps.BackColor = Color.Transparent;
            lblContagemApps.Font = new Font("Segoe UI", 10F);
            lblContagemApps.ForeColor = Color.FromArgb(192, 132, 252);
            lblContagemApps.Location = new Point(54, 450);
            lblContagemApps.Name = "lblContagemApps";
            lblContagemApps.Size = new Size(300, 24);
            lblContagemApps.TabIndex = 6;
            lblContagemApps.Text = "0 app(s) selecionado(s) para remoção";
            // 
            // lblLegendaApps
            // 
            lblLegendaApps.BackColor = Color.Transparent;
            lblLegendaApps.Font = new Font("Segoe UI", 9.5F);
            lblLegendaApps.ForeColor = Color.FromArgb(159, 143, 196);
            lblLegendaApps.Location = new Point(360, 450);
            lblLegendaApps.Name = "lblLegendaApps";
            lblLegendaApps.Size = new Size(434, 24);
            lblLegendaApps.TabIndex = 7;
            lblLegendaApps.Text = "Verde = recomendado   |   Amarelo = opcional   |   Vermelho = não recomendado";
            lblLegendaApps.TextAlign = ContentAlignment.MiddleRight;
            // 
            // uiButton12
            // 
            uiButton12.Cursor = Cursors.Hand;
            uiButton12.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            uiButton12.Location = new Point(54, 482);
            uiButton12.MinimumSize = new Size(1, 1);
            uiButton12.Name = "uiButton12";
            uiButton12.Size = new Size(300, 50);
            uiButton12.TabIndex = 8;
            uiButton12.Text = "Remover selecionados";
            uiButton12.TipsFont = new Font("Microsoft Sans Serif", 9F);
            uiButton12.Click += uiButton12_Click;
            // 
            // progressBarRemocao
            // 
            progressBarRemocao.Location = new Point(54, 544);
            progressBarRemocao.Name = "progressBarRemocao";
            progressBarRemocao.Size = new Size(740, 8);
            progressBarRemocao.TabIndex = 9;
            // 
            // lblStatusRemocao
            // 
            lblStatusRemocao.BackColor = Color.Transparent;
            lblStatusRemocao.Font = new Font("Segoe UI", 10.5F);
            lblStatusRemocao.ForeColor = Color.FromArgb(192, 132, 252);
            lblStatusRemocao.Location = new Point(54, 558);
            lblStatusRemocao.Name = "lblStatusRemocao";
            lblStatusRemocao.Size = new Size(740, 30);
            lblStatusRemocao.TabIndex = 10;
            lblStatusRemocao.Text = "Marque os apps e clique em remover. Execute como Administrador.";
            // 
            // tabPage7
            // 
            tabPage7.Controls.Add(uiButton13);
            tabPage7.Controls.Add(lblDescAvancado);
            tabPage7.Controls.Add(lblAvancado);
            tabPage7.Location = new Point(181, 0);
            tabPage7.Name = "tabPage7";
            tabPage7.Size = new Size(819, 605);
            tabPage7.TabIndex = 6;
            tabPage7.Text = "Tweaks avançados";
            tabPage7.UseVisualStyleBackColor = true;
            // 
            // lblAvancado
            // 
            lblAvancado.AutoSize = true;
            lblAvancado.BackColor = Color.Transparent;
            lblAvancado.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblAvancado.ForeColor = Color.FromArgb(243, 232, 255);
            lblAvancado.Location = new Point(50, 40);
            lblAvancado.Name = "lblAvancado";
            lblAvancado.Size = new Size(300, 45);
            lblAvancado.TabIndex = 0;
            lblAvancado.Text = "Tweaks avançados";
            // 
            // lblDescAvancado
            // 
            lblDescAvancado.BackColor = Color.Transparent;
            lblDescAvancado.Font = new Font("Segoe UI", 11F);
            lblDescAvancado.ForeColor = Color.FromArgb(159, 143, 196);
            lblDescAvancado.Location = new Point(54, 105);
            lblDescAvancado.Name = "lblDescAvancado";
            lblDescAvancado.Size = new Size(700, 70);
            lblDescAvancado.TabIndex = 1;
            lblDescAvancado.Text = "Abre uma tela separada com tweaks de privacidade, IA, Windows Update, jogos e mais. Dá para aplicar, reverter e detectar o que já está ativo.";
            // 
            // uiButton13
            // 
            uiButton13.Cursor = Cursors.Hand;
            uiButton13.Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold);
            uiButton13.Location = new Point(54, 195);
            uiButton13.MinimumSize = new Size(1, 1);
            uiButton13.Name = "uiButton13";
            uiButton13.Size = new Size(340, 60);
            uiButton13.TabIndex = 2;
            uiButton13.Text = "Abrir tweaks avançados";
            uiButton13.TipsFont = new Font("Microsoft Sans Serif", 9F);
            uiButton13.Click += uiButton13_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 640);
            Controls.Add(uiTabControlMenu1);
            MinimumSize = new Size(900, 600);
            Name = "Form1";
            Padding = new Padding(0, 35, 0, 0);
            ShowTitleIcon = true;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MeskTweaks";
            uiTabControlMenu1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            tabPage5.ResumeLayout(false);
            tabPage5.PerformLayout();
            tabPage6.ResumeLayout(false);
            tabPage6.PerformLayout();
            tabPage7.ResumeLayout(false);
            tabPage7.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Sunny.UI.UIButton uiButton1;
        private Sunny.UI.UITabControlMenu uiTabControlMenu1;
        private TabPage tabPage1;
        private Sunny.UI.UIButton uiButton2;
        private TabPage tabPage2;
        private Label lblTitulo;
        private Label lblDescricao;
        private Label lblStatus;
        private Label lblApps;
        private CheckedListBox checkedListBox1;
        private Sunny.UI.UIButton uiButton3;
        private Sunny.UI.UIButton uiButton4;
        private ProgressBar progressBar1;
        private Label lblStatusApps;
        private TabPage tabPage3;
        private Label lblFerramentas;
        private Label lblDescFerramentas;
        private Sunny.UI.UIButton uiButton5;
        private Label lblStatusFerramentas;
        private TabPage tabPage5;
        private Label lblConfig;
        private Label lblDescConfig;
        private CheckBox chkTemaEscuro;
        private CheckBox chkTransparencia;
        private CheckBox chkNotificacoes;
        private CheckBox chkSugestoes;
        private CheckBox chkModoJogo;
        private CheckBox chkExtensoes;
        private CheckBox chkOcultos;
        private CheckBox chkMenuClassico;
        private CheckBox chkBarraEsquerda;
        private CheckBox chkWidgets;
        private CheckBox chkBusca;
        private CheckBox chkVisaoTarefas;
        private Sunny.UI.UIButton uiButton7;
        private Sunny.UI.UIButton uiButton8;
        private Sunny.UI.UIButton uiButton9;
        private Label lblStatusConfig;
        private TabPage tabPage6;
        private Label lblRemover;
        private Sunny.UI.UIButton uiButton10;
        private Sunny.UI.UIButton uiButton11;
        private TextBox txtBuscaApps;
        private CheckBox chkSoInstalados;
        private ListView lvApps;
        private ColumnHeader colNomeApp;
        private ColumnHeader colDescApp;
        private ColumnHeader colIdApp;
        private Label lblContagemApps;
        private Label lblLegendaApps;
        private Sunny.UI.UIButton uiButton12;
        private ProgressBar progressBarRemocao;
        private Label lblStatusRemocao;
        private TabPage tabPage7;
        private Label lblAvancado;
        private Label lblDescAvancado;
        private Sunny.UI.UIButton uiButton13;
    }
}