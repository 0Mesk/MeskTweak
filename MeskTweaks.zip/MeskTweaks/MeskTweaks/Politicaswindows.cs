﻿using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

namespace MeskTweaks
{
    /// <summary>
    /// Altera a Política de Grupo LOCAL (a mesma que o gpedit.msc edita), usando a API oficial
    /// IGroupPolicyObject. Os valores vão para o Registry.pol, então aparecem no gpedit
    /// como "Habilitado/Desabilitado", e "Voltar ao padrão" volta para "Não configurado".
    /// PRECISA rodar como Administrador.
    /// </summary>
    public static class PoliticasWindows
    {
        // ------------------------------------------------------------------
        //  Interop da API do Editor de Política de Grupo (gpedit.h)
        // ------------------------------------------------------------------
        [ComImport, Guid("EA502722-A23D-11d1-A7D3-0000F87571E3")]
        private class GroupPolicyObjectCom { }

        [ComImport, Guid("EA502723-A23D-11d1-A7D3-0000F87571E3"),
         InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IGroupPolicyObject
        {
            void New([MarshalAs(UnmanagedType.LPWStr)] string pszDomainName,
                     [MarshalAs(UnmanagedType.LPWStr)] string pszDisplayName, uint dwFlags);
            void OpenDSGPO([MarshalAs(UnmanagedType.LPWStr)] string pszPath, uint dwFlags);
            void OpenLocalMachineGPO(uint dwFlags);
            void OpenRemoteMachineGPO([MarshalAs(UnmanagedType.LPWStr)] string pszComputerName, uint dwFlags);
            void Save([MarshalAs(UnmanagedType.Bool)] bool bMachine, [MarshalAs(UnmanagedType.Bool)] bool bAdd,
                      [MarshalAs(UnmanagedType.LPStruct)] Guid pGuidExtension,
                      [MarshalAs(UnmanagedType.LPStruct)] Guid pGuid);
            void Delete();
            void GetName([MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszName, int cchMaxLength);
            void GetDisplayName([MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszName, int cchMaxLength);
            void SetDisplayName([MarshalAs(UnmanagedType.LPWStr)] string pszName);
            void GetPath([MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszPath, int cchMaxPath);
            void GetDSPath(uint dwSection, [MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszPath, int cchMaxPath);
            void GetFileSysPath(uint dwSection, [MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszPath, int cchMaxPath);
            void GetRegistryKey(uint dwSection, out IntPtr hKey);
        }

        private const uint GPO_OPEN_LOAD_REGISTRY = 0x00000001;
        private const uint GPO_SECTION_USER = 1;
        private const uint GPO_SECTION_MACHINE = 2;

        // Extensão "Registry" e snap-in do gpedit
        private static readonly Guid ExtensaoRegistro = new Guid("35378EAC-683F-11D2-A89A-00C04FBBCFA2");
        private static readonly Guid SnapInGpedit = new Guid("0F6B957E-509E-11D1-A7CC-0000F87571E3");

        // ------------------------------------------------------------------
        //  Lista de políticas
        // ------------------------------------------------------------------
        private sealed class Politica
        {
            public string Grupo = "";
            public string Descricao = "";
            public bool Usuario;          // false = Configuração do Computador, true = do Usuário
            public string Caminho = "";
            public string Valor = "";
            public int Dado;
        }

        private const string POL = @"Software\Policies\Microsoft\";
        private static readonly List<Politica> Lista = new List<Politica>();

        static PoliticasWindows()
        {
            // ===== Coleta de dados e compilações de visualização =====
            string dc = POL + @"Windows\DataCollection";
            string ac = POL + @"Windows\AppCompat";
            Add("Coleta de dados", "Permitir dados de diagnóstico (Desativado)", dc, "AllowTelemetry", 0);
            Add("Coleta de dados", "Desativar telemetria de aplicativos", ac, "AITEnable", 0);
            Add("Coleta de dados", "Desativar mecanismo de compatibilidade de aplicativos", ac, "DisableEngine", 1);
            Add("Coleta de dados", "Desativar auxiliar de compatibilidade de programa", ac, "DisablePCA", 1);
            Add("Coleta de dados", "Desativar coletor de inventário", ac, "DisableInventory", 1);
            Add("Coleta de dados", "Desativar mecanismo de compatibilidade de switchback", ac, "SbEnable", 0);
            Add("Coleta de dados", "Desativar gravador de passos", ac, "DisableUAR", 1);

            // ===== Conteúdo da nuvem =====
            string cc = POL + @"Windows\CloudContent";
            Add("Conteúdo da nuvem", "Desativar conteúdo otimizado em nuvem", cc, "DisableCloudOptimizedContent", 1);
            Add("Conteúdo da nuvem", "Desligar conteúdo do estado da conta do consumidor na nuvem", cc, "DisableConsumerAccountStateContent", 1);
            Add("Conteúdo da nuvem", "Não mostrar dicas do Windows", cc, "DisableSoftLanding", 1);
            Add("Conteúdo da nuvem", "Desativar experiências do cliente da Microsoft", cc, "DisableWindowsConsumerFeatures", 1);

            // ===== Controle por voz =====
            Add("Controle por voz", "Permitir atualização automática de dados de fala (Desabilitado)", POL + @"Speech", "AllowSpeechModelUpdate", 0);

            // ===== Explorador de Arquivos =====
            Add("Explorador de Arquivos", "Desativar insights de conta, arquivos recentes, favoritos e recomendados",
                POL + @"Windows\Explorer", "DisableGraphRecentItems", 1);

            // ===== Local e sensores =====
            string ls = POL + @"Windows\LocationAndSensors";
            Add("Local e sensores", "Desativar fornecedor de local do Windows", ls, "DisableWindowsLocationProvider", 1);
            Add("Local e sensores", "Desativar local", ls, "DisableLocation", 1);
            Add("Local e sensores", "Desativar sensores", ls, "DisableSensors", 1);

            // ===== Loja =====
            Add("Loja", "Desabilitar download e instalação automáticos de atualizações", POL + @"WindowsStore", "AutoDownload", 2);

            // ===== Microsoft Edge =====
            Add("Microsoft Edge", "Não carregar Página Inicial/Nova Guia na inicialização do Windows (Desabilitado)",
                POL + @"MicrosoftEdge\TabPreloader", "AllowTabPreloading", 0);
            Add("Microsoft Edge", "Desativar pré-inicialização do Edge (Desabilitado)",
                POL + @"MicrosoftEdge\Main", "AllowPrelaunch", 0);

            // ===== Pesquisar =====
            string ws = POL + @"Windows\Windows Search";
            Add("Pesquisar", "Permitir Cortana (Desabilitado)", ws, "AllowCortana", 0);
            Add("Pesquisar", "Permitir pesquisa na nuvem (Desabilitado)", ws, "AllowCloudSearch", 0);
            Add("Pesquisar", "Permitir destaques de pesquisa (Desabilitado)", ws, "EnableDynamicContentInWSB", 0);
            Add("Pesquisar", "Permitir que Pesquisa e Cortana usem a localização (Desabilitado)", ws, "AllowSearchToUseLocation", 0);
            Add("Pesquisar", "Sempre usar detecção automática de idioma ao indexar (Desabilitado)", ws, "AlwaysUseAutoLangDetection", 0);

            // ===== Privacidade de aplicativos =====
            Add("Privacidade de aplicativos", "Aplicativos do Windows em segundo plano (Forçar negação)",
                POL + @"Windows\AppPrivacy", "LetAppsRunInBackground", 2);

            // ===== Menu Iniciar e barra de tarefas (Configuração do Usuário) =====
            AddUsuario("Menu Iniciar e barra de tarefas", "Não manter histórico de documentos abertos recentemente",
                @"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer", "NoRecentDocsHistory", 1);

            // ===== Políticas do SO =====
            string sy = POL + @"Windows\System";
            Add("Políticas do SO", "Habilitar feed de atividades (Desabilitado)", sy, "EnableActivityFeed", 0);
            Add("Políticas do SO", "Permitir sincronização da área de transferência entre dispositivos (Desabilitado)", sy, "AllowCrossDeviceClipboard", 0);
            Add("Políticas do SO", "Permitir publicação das atividades do usuário (Desabilitado)", sy, "PublishUserActivities", 0);
        }

        private static void Add(string grupo, string desc, string caminho, string valor, int dado)
        {
            Lista.Add(new Politica { Grupo = grupo, Descricao = desc, Usuario = false, Caminho = caminho, Valor = valor, Dado = dado });
        }

        private static void AddUsuario(string grupo, string desc, string caminho, string valor, int dado)
        {
            Lista.Add(new Politica { Grupo = grupo, Descricao = desc, Usuario = true, Caminho = caminho, Valor = valor, Dado = dado });
        }

        // ------------------------------------------------------------------
        //  DESATIVAR TUDO  (vira "Habilitado/Desabilitado" no gpedit)
        // ------------------------------------------------------------------
        public static List<string> DesativarTudo()
        {
            var log = new List<string>();
            ProcessarSecao(false, true, log);
            ProcessarSecao(true, true, log);

            log.Add("");
            log.Add("[Serviços de telemetria]");
            log.Add(Servico("DiagTrack", "disabled", false));
            log.Add(Servico("dmwappushservice", "disabled", false));

            AtualizarPoliticas();
            return log;
        }

        // ------------------------------------------------------------------
        //  VOLTAR AO PADRÃO  (vira "Não configurado" no gpedit)
        // ------------------------------------------------------------------
        public static List<string> RestaurarPadrao()
        {
            var log = new List<string>();
            LimparResiduosAntigos();
            ProcessarSecao(false, false, log);
            ProcessarSecao(true, false, log);

            log.Add("");
            log.Add("[Serviços de telemetria]");
            log.Add(Servico("DiagTrack", "auto", true));
            log.Add(Servico("dmwappushservice", "demand", false));

            AtualizarPoliticas();
            return log;
        }

        // ------------------------------------------------------------------
        //  Núcleo: abre a GPO local, grava/remove e salva (igual ao gpedit)
        // ------------------------------------------------------------------
        // O objeto COM da GPO só funciona em thread STA (Task.Run usa MTA e causa E_NOINTERFACE).
        private static void ProcessarSecao(bool usuario, bool aplicar, List<string> log)
        {
            var t = new Thread(() => ProcessarSecaoSta(usuario, aplicar, log));
            t.SetApartmentState(ApartmentState.STA);
            t.Start();
            t.Join();
        }

        private static void ProcessarSecaoSta(bool usuario, bool aplicar, List<string> log)
        {
            IGroupPolicyObject? gpo = null;
            try
            {
                gpo = (IGroupPolicyObject)new GroupPolicyObjectCom();
                gpo.OpenLocalMachineGPO(GPO_OPEN_LOAD_REGISTRY);
                gpo.GetRegistryKey(usuario ? GPO_SECTION_USER : GPO_SECTION_MACHINE, out IntPtr hKey);

                using (var raiz = RegistryKey.FromHandle(new SafeRegistryHandle(hKey, true)))
                {
                    string? grupoAtual = null;

                    foreach (var p in Lista)
                    {
                        if (p.Usuario != usuario) continue;

                        if (p.Grupo != grupoAtual)
                        {
                            grupoAtual = p.Grupo;
                            log.Add("");
                            log.Add("[" + grupoAtual + "]");
                        }

                        try
                        {
                            if (aplicar)
                            {
                                using (var k = raiz.CreateSubKey(p.Caminho, true))
                                    k.SetValue(p.Valor, p.Dado, RegistryValueKind.DWord);
                                log.Add("  OK    " + p.Descricao);
                            }
                            else
                            {
                                using (var k = raiz.OpenSubKey(p.Caminho, true))
                                {
                                    if (k != null && k.GetValue(p.Valor) != null)
                                        k.DeleteValue(p.Valor, false);
                                }

                                // remove a chave se ficou vazia
                                bool vazia = false;
                                using (var k = raiz.OpenSubKey(p.Caminho, false))
                                    vazia = k != null && k.ValueCount == 0 && k.SubKeyCount == 0;
                                if (vazia) raiz.DeleteSubKey(p.Caminho, false);

                                log.Add("  OK    " + p.Descricao + " -> Não configurado");
                            }
                        }
                        catch (Exception ex)
                        {
                            log.Add("  ERRO  " + p.Descricao + " -> " + ex.Message);
                        }
                    }

                    // grava no Registry.pol (como o botão Aplicar/OK do gpedit)
                    gpo.Save(!usuario, true, ExtensaoRegistro, SnapInGpedit);
                }
            }
            catch (Exception ex)
            {
                log.Add("  ERRO  Política de Grupo (" + (usuario ? "Usuário" : "Computador") + ") -> " + ex.Message);
            }
            finally
            {
                if (gpo != null) Marshal.ReleaseComObject(gpo);
            }
        }

        // Remove valores que a versão antiga do programa gravou direto no registro
        private static void LimparResiduosAntigos()
        {
            foreach (var p in Lista)
            {
                try
                {
                    var hive = p.Usuario ? RegistryHive.CurrentUser : RegistryHive.LocalMachine;
                    using (var b = RegistryKey.OpenBaseKey(hive, RegistryView.Registry64))
                    using (var k = b.OpenSubKey(p.Caminho, true))
                    {
                        if (k != null && k.GetValue(p.Valor) != null) k.DeleteValue(p.Valor, false);
                    }
                }
                catch { }
            }
        }

        // ------------------------------------------------------------------
        //  Auxiliares
        // ------------------------------------------------------------------
        private static string Servico(string nome, string tipoInicio, bool iniciar)
        {
            try
            {
                if (tipoInicio == "disabled")
                    Sc("stop " + nome);

                int cod = Sc("config " + nome + " start= " + tipoInicio);

                if (iniciar)
                    Sc("start " + nome);

                return cod == 0
                    ? "  OK    Serviço " + nome + " -> " + tipoInicio
                    : "  AVISO Serviço " + nome + " (sc retornou " + cod + ")";
            }
            catch (Exception ex)
            {
                return "  ERRO  Serviço " + nome + " -> " + ex.Message;
            }
        }

        private static int Sc(string args)
        {
            var psi = new ProcessStartInfo("sc.exe", args)
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                WindowStyle = ProcessWindowStyle.Hidden
            };
            using (var proc = Process.Start(psi))
            {
                if (proc == null) return -1;
                proc.WaitForExit(15000);
                return proc.HasExited ? proc.ExitCode : -1;
            }
        }

        private static void AtualizarPoliticas()
        {
            try
            {
                var psi = new ProcessStartInfo("gpupdate.exe", "/force")
                {
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                using (var proc = Process.Start(psi))
                    proc?.WaitForExit(60000);
            }
            catch { }
        }
    }
}