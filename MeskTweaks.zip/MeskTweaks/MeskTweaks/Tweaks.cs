﻿using Microsoft.Win32;
using System.Diagnostics;

namespace MeskTweaks
{
    internal enum Raiz { Usuario, Maquina }

    // Valor    = grava/lê um valor (int => DWord, string => texto)
    // ChavePresente = a chave precisa existir (aplicar cria, reverter apaga)
    // ChaveAusente  = a chave precisa NÃO existir (aplicar apaga, reverter recria)
    internal enum Modo { Valor, ChavePresente, ChaveAusente }

    internal record Valor(
        Raiz Raiz,
        string SubChave,
        string? Nome,
        object? Ligado,
        object? Desligado,
        Modo Modo = Modo.Valor,
        bool SoSeExiste = false)
    {
        private RegistryKey Base => Raiz == Raiz.Usuario ? Registry.CurrentUser : Registry.LocalMachine;

        public bool Confere()
        {
            try
            {
                using var k = Base.OpenSubKey(SubChave);

                if (Modo == Modo.ChavePresente) return k != null;
                if (Modo == Modo.ChaveAusente) return k == null;

                object? v = k?.GetValue(Nome!);
                return v != null && Convert.ToString(v) == Convert.ToString(Ligado);
            }
            catch
            {
                return false;
            }
        }

        public void Aplicar()
        {
            if (Modo == Modo.ChavePresente)
            {
                Base.CreateSubKey(SubChave, true).Dispose();
            }
            else if (Modo == Modo.ChaveAusente)
            {
                Base.DeleteSubKeyTree(SubChave, false);
            }
            else
            {
                if (SoSeExiste && !ChaveExiste()) return;
                Escrever(Ligado!);
            }
        }

        public void Reverter()
        {
            if (Modo == Modo.ChavePresente)
            {
                Base.DeleteSubKeyTree(SubChave, false);
            }
            else if (Modo == Modo.ChaveAusente)
            {
                using var k = Base.CreateSubKey(SubChave, true);
                if (Desligado is string padrao)
                    k.SetValue("", padrao, RegistryValueKind.String);
            }
            else
            {
                if (SoSeExiste && !ChaveExiste()) return;

                if (Desligado != null)
                {
                    Escrever(Desligado);
                }
                else
                {
                    using var k = Base.OpenSubKey(SubChave, true);
                    k?.DeleteValue(Nome!, false);
                }
            }
        }

        private bool ChaveExiste()
        {
            using var k = Base.OpenSubKey(SubChave);
            return k != null;
        }

        private void Escrever(object valor)
        {
            using var k = Base.CreateSubKey(SubChave, true);
            k.SetValue(Nome!, valor, valor is int ? RegistryValueKind.DWord : RegistryValueKind.String);
        }
    }

    // Atalhos para deixar a lista curta
    internal static class Reg
    {
        public static Valor U(string sub, string nome, object ligado, object? desligado = null, bool soSeExiste = false)
            => new(Raiz.Usuario, sub, nome, ligado, desligado, Modo.Valor, soSeExiste);

        public static Valor M(string sub, string nome, object ligado, object? desligado = null, bool soSeExiste = false)
            => new(Raiz.Maquina, sub, nome, ligado, desligado, Modo.Valor, soSeExiste);

        public static Valor CriaChaveM(string sub)
            => new(Raiz.Maquina, sub, null, null, null, Modo.ChavePresente);

        public static Valor ApagaChaveM(string sub, string? padrao)
            => new(Raiz.Maquina, sub, null, null, padrao, Modo.ChaveAusente);
    }

    // ===================== Itens =====================

    internal abstract class Item
    {
        public string Categoria { get; }
        public string Texto { get; }

        protected Item(string categoria, string texto)
        {
            Categoria = categoria;
            Texto = texto;
        }

        public abstract bool RequerAdmin { get; }
        public abstract bool EstaAplicado();
        public abstract void Aplicar();
        public abstract void Reverter();
    }

    // Caixa de seleção ligada a um ou mais valores do registro
    internal sealed class Tweak : Item
    {
        public Valor[] Valores { get; }

        public Tweak(string categoria, string texto, params Valor[] valores) : base(categoria, texto)
        {
            Valores = valores;
        }

        public override bool RequerAdmin => Valores.Any(v => v.Raiz == Raiz.Maquina);
        public override bool EstaAplicado() => Valores.All(v => v.Confere());

        public override void Aplicar()
        {
            foreach (var v in Valores) v.Aplicar();
        }

        public override void Reverter()
        {
            foreach (var v in Valores) v.Reverter();
        }
    }

    // Recurso opcional do Windows (usa PowerShell, precisa de Administrador)
    internal sealed class Recurso : Item
    {
        private readonly string _feature;

        public Recurso(string categoria, string texto, string feature) : base(categoria, texto)
        {
            _feature = feature;
        }

        public override bool RequerAdmin => true;

        public override bool EstaAplicado()
        {
            try
            {
                string saida = PowerShell("(Get-WindowsOptionalFeature -Online -FeatureName " + _feature + ").State");
                return saida.Trim().Equals("Enabled", StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        public override void Aplicar() =>
            PowerShell("Enable-WindowsOptionalFeature -Online -FeatureName " + _feature + " -All -NoRestart | Out-Null");

        public override void Reverter() =>
            PowerShell("Disable-WindowsOptionalFeature -Online -FeatureName " + _feature + " -NoRestart | Out-Null");

        private static string PowerShell(string comando)
        {
            var psi = new ProcessStartInfo("powershell.exe",
                "-NoProfile -NonInteractive -ExecutionPolicy Bypass -Command \"" + comando + "\"")
            {
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            using var p = Process.Start(psi) ?? throw new InvalidOperationException("Não foi possível iniciar o PowerShell.");
            string saida = p.StandardOutput.ReadToEnd();
            string erro = p.StandardError.ReadToEnd();
            p.WaitForExit();

            if (p.ExitCode != 0)
                throw new InvalidOperationException(erro.Trim().Length > 0 ? erro.Trim() : "PowerShell retornou o código " + p.ExitCode);

            return saida;
        }
    }

    internal sealed class Opcao
    {
        public string Rotulo { get; }
        public Valor[] Valores { get; }

        public Opcao(string rotulo, params Valor[] valores)
        {
            Rotulo = rotulo;
            Valores = valores;
        }
    }

    // Lista suspensa ("Sem alteração" + opções)
    internal sealed class Escolha : Item
    {
        public IReadOnlyList<Opcao> Opcoes { get; }

        // 0 = Sem alteração; 1..n = opção escolhida
        public int Indice { get; set; }

        public Escolha(string categoria, string texto, params Opcao[] opcoes) : base(categoria, texto)
        {
            Opcoes = opcoes;
        }

        public override bool RequerAdmin =>
            Opcoes.Any(o => o.Valores.Any(v => v.Raiz == Raiz.Maquina));

        // Descobre qual opção está ativa no Windows (0 = nenhuma)
        public int Detectar()
        {
            for (int i = 0; i < Opcoes.Count; i++)
                if (Opcoes[i].Valores.All(v => v.Confere()))
                    return i + 1;
            return 0;
        }

        public override bool EstaAplicado() => Detectar() > 0;

        public override void Aplicar()
        {
            if (Indice <= 0) return;
            foreach (var v in Opcoes[Indice - 1].Valores) v.Aplicar();
        }

        public override void Reverter()
        {
            foreach (var o in Opcoes)
                foreach (var v in o.Valores)
                    v.Reverter();
        }
    }

    // ===================== Lista completa =====================

    internal static class Tweaks
    {
        private const string Pol = @"SOFTWARE\Policies\Microsoft\Windows";
        private const string Adv = @"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced";
        private const string CDM = @"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager";
        private const string Edge = @"SOFTWARE\Policies\Microsoft\Edge";
        private const string WinAI = Pol + @"\WindowsAI";
        private const string ThisPC = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\";
        private const string Dup = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\DelegateFolders\{F5FB2C77-0E2F-4A16-A381-3E560C68BC83}";
        private const string DupWow = @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\DelegateFolders\{F5FB2C77-0E2F-4A16-A381-3E560C68BC83}";

        private const string cPriv = "Privacidade e conteúdo sugerido";
        private const string cIA = "Inteligência Artificial";
        private const string cApar = "Aparência";
        private const string cMulti = "Multitarefa";
        private const string cSis = "Sistema";
        private const string cUpd = "Windows Update";
        private const string cExp = "Explorador de Arquivos";
        private const string cRec = "Recursos opcionais do Windows";
        private const string cIni = "Menu Iniciar e Pesquisa";
        private const string cBarra = "Barra de tarefas";
        private const string cJogo = "Jogos";
        private const string cOutros = "Outros";

        public static readonly List<Item> Lista = new()
        {
            // ================= Privacidade e conteúdo sugerido =================
            new Tweak(cPriv, "Desativar rastreamento do 'Encontrar meu dispositivo'",
                Reg.M(@"SOFTWARE\Policies\Microsoft\FindMyDevice", "AllowFindMyDevice", 0),
                Reg.M(@"SOFTWARE\Microsoft\Settings\FindMyDevice", "LocationSyncEnabled", 0, 1)),

            new Tweak(cPriv, "Desativar dicas e truques na tela de bloqueio",
                Reg.U(CDM, "RotatingLockScreenOverlayEnabled", 0, 1),
                Reg.U(CDM, "SubscribedContent-338387Enabled", 0, 1)),

            new Tweak(cPriv, "Desativar anúncios, sugestões e feed de notícias no Edge",
                Reg.M(Edge, "NewTabPageContentEnabled", 0),
                Reg.M(Edge, "ShowRecommendationsEnabled", 0),
                Reg.M(Edge, "PersonalizationReportingEnabled", 0),
                Reg.M(Edge, "SpotlightExperiencesAndRecommendationsEnabled", 0),
                Reg.M(Edge, "EdgeShoppingAssistantEnabled", 0),
                Reg.M(Edge, "ShowMicrosoftRewards", 0)),

            new Tweak(cPriv, "Ocultar anúncios do Microsoft 365 Copilot na Home das Configurações",
                Reg.U(@"Software\Microsoft\Windows\CurrentVersion\SystemSettings\AccountNotifications", "EnableAccountNotifications", 0, 1)),

            // ================= IA =================
            new Tweak(cIA, "Desativar Microsoft Copilot",
                Reg.U(@"Software\Policies\Microsoft\Windows\WindowsCopilot", "TurnOffWindowsCopilot", 1),
                Reg.M(Pol + @"\WindowsCopilot", "TurnOffWindowsCopilot", 1),
                Reg.U(Adv, "ShowCopilotButton", 0, 1)),

            new Tweak(cIA, "Desativar Windows Recall",
                Reg.M(WinAI, "DisableAIDataAnalysis", 1),
                Reg.M(WinAI, "AllowRecallEnablement", 0)),

            new Tweak(cIA, "Desativar Click To Do e análise de texto/imagem por IA",
                Reg.M(WinAI, "DisableClickToDo", 1),
                Reg.U(@"Software\Policies\Microsoft\Windows\WindowsAI", "DisableClickToDo", 1)),

            new Tweak(cIA, "Impedir que o serviço de IA inicie automaticamente",
                Reg.M(@"SYSTEM\CurrentControlSet\Services\WSAIFabricSvc", "Start", 4, 2, soSeExiste: true)),

            new Tweak(cIA, "Desativar recursos de IA no Microsoft Edge",
                Reg.M(Edge, "CopilotPageContext", 0),
                Reg.M(Edge, "HubsSidebarEnabled", 0),
                Reg.M(Edge, "Microsoft365CopilotChatIconEnabled", 0),
                Reg.M(Edge, "ComposeInlineEnabled", 0)),

            new Tweak(cIA, "Desativar recursos de IA no Paint",
                Reg.M(Pol + @"\Paint", "DisableCocreator", 1),
                Reg.M(Pol + @"\Paint", "DisableGenerativeFill", 1),
                Reg.M(Pol + @"\Paint", "DisableImageCreator", 1)),

            new Tweak(cIA, "Desativar recursos de IA no Bloco de Notas",
                Reg.M(@"SOFTWARE\Policies\WindowsNotepad", "DisableAIFeatures", 1)),

            // ================= Aparência =================
            new Tweak(cApar, "Desativar animações e efeitos visuais",
                Reg.U(@"Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects", "VisualFXSetting", 2, 0),
                Reg.U(Adv, "TaskbarAnimations", 0, 1),
                Reg.U(@"Control Panel\Desktop\WindowMetrics", "MinAnimate", "0", "1")),

            new Escolha(cApar, "Windows Spotlight na área de trabalho",
                new Opcao("Desativar Spotlight na área de trabalho",
                    Reg.U(@"Software\Policies\Microsoft\Windows\CloudContent", "DisableSpotlightCollectionOnDesktop", 1)),
                new Opcao("Ocultar o ícone do Spotlight",
                    Reg.U(@"Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel",
                          "{2cc5ca98-6485-489a-920e-b3e88a6ccce3}", 1))),

            // ================= Multitarefa =================
            new Tweak(cMulti, "Desativar o encaixe de janelas (window snapping)",
                Reg.U(@"Control Panel\Desktop", "WindowArrangementActive", "0", "1")),

            new Tweak(cMulti, "Desativar sugestões de apps ao encaixar janelas",
                Reg.U(Adv, "SnapAssist", 0, 1)),

            new Tweak(cMulti, "Ocultar o flyout de layouts de encaixe (topo da tela e botão maximizar)",
                Reg.U(Adv, "EnableSnapAssistFlyout", 0, 1),
                Reg.U(Adv, "EnableSnapBar", 0, 1)),

            new Escolha(cMulti, "Mostrar abas dos apps ao encaixar ou pressionar Alt+Tab",
                new Opcao("Não mostrar abas", Reg.U(Adv, "MultiTaskingAltTabFilter", 3)),
                new Opcao("Mostrar as 3 abas mais recentes", Reg.U(Adv, "MultiTaskingAltTabFilter", 2)),
                new Opcao("Mostrar as 5 abas mais recentes", Reg.U(Adv, "MultiTaskingAltTabFilter", 1)),
                new Opcao("Mostrar todas as abas", Reg.U(Adv, "MultiTaskingAltTabFilter", 0))),

            // ================= Sistema =================
            new Tweak(cSis, "Desativar a 'Bandeja de arrastar' para compartilhar e mover arquivos",
                Reg.U(@"Software\Microsoft\Windows\CurrentVersion\CDP", "DragTrayEnabled", 0, 1)),

            new Tweak(cSis, "Desativar 'Aprimorar precisão do ponteiro' (aceleração do mouse)",
                Reg.U(@"Control Panel\Mouse", "MouseSpeed", "0", "1"),
                Reg.U(@"Control Panel\Mouse", "MouseThreshold1", "0", "6"),
                Reg.U(@"Control Panel\Mouse", "MouseThreshold2", "0", "10")),

            new Tweak(cSis, "Desativar atalho das Teclas de Aderência (5x Shift)",
                Reg.U(@"Control Panel\Accessibility\StickyKeys", "Flags", "58", "510")),

            new Tweak(cSis, "Desativar limpeza automática de disco (Sensor de Armazenamento)",
                Reg.U(@"Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy", "01", 0, 1)),

            new Tweak(cSis, "Desativar inicialização rápida",
                Reg.M(@"SYSTEM\CurrentControlSet\Control\Session Manager\Power", "HiberbootEnabled", 0, 1)),

            new Tweak(cSis, "Desativar criptografia automática de dispositivo do BitLocker",
                Reg.M(@"SYSTEM\CurrentControlSet\Control\BitLocker", "PreventDeviceEncryption", 1, 0)),

            // ================= Windows Update =================
            new Tweak(cUpd, "Impedir receber atualizações assim que ficam disponíveis",
                Reg.M(@"SOFTWARE\Microsoft\WindowsUpdate\UX\Settings", "IsContinuousInnovationOptedIn", 0)),

            new Tweak(cUpd, "Impedir reinício automático após atualizações com usuário conectado",
                Reg.M(Pol + @"\WindowsUpdate\AU", "NoAutoRebootWithLoggedOnUsers", 1)),

            new Tweak(cUpd, "Desativar compartilhamento de atualizações baixadas com outros PCs",
                Reg.M(Pol + @"\DeliveryOptimization", "DODownloadMode", 0),
                Reg.M(@"SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config", "DODownloadMode", 0, 1)),

            new Tweak(cUpd, "Impedir instalação automática de apps complementares de dispositivos",
                Reg.M(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Device Metadata", "PreventDeviceMetadataFromNetwork", 1, 0)),

            // ================= Explorador de Arquivos =================
            new Escolha(cExp, "Abrir o Explorador de Arquivos em",
                new Opcao("Este Computador", Reg.U(Adv, "LaunchTo", 1)),
                new Opcao("Início", Reg.U(Adv, "LaunchTo", 2)),
                new Opcao("Downloads", Reg.U(Adv, "LaunchTo", 3)),
                new Opcao("OneDrive", Reg.U(Adv, "LaunchTo", 4))),

            new Tweak(cExp, "Ocultar entradas duplicadas de unidades removíveis",
                Reg.ApagaChaveM(Dup, "Removable Drives"),
                Reg.ApagaChaveM(DupWow, "Removable Drives")),

            new Tweak(cExp, "Ocultar 'Início' do painel de navegação",
                Reg.U(@"Software\Classes\CLSID\{f874310e-b6b7-47dc-bc84-b9e6b38f5903}", "System.IsPinnedToNameSpaceTree", 0)),

            new Tweak(cExp, "Ocultar 'Galeria' do painel de navegação",
                Reg.U(@"Software\Classes\CLSID\{e88865ea-0e1c-4e20-9aa6-edcd0212c87c}", "System.IsPinnedToNameSpaceTree", 0)),

            new Tweak(cExp, "Ocultar 'OneDrive' do painel de navegação",
                Reg.U(@"Software\Classes\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}", "System.IsPinnedToNameSpaceTree", 0)),

            new Tweak(cExp, "Adicionar pastas comuns de volta em 'Este Computador'",
                Reg.CriaChaveM(ThisPC + "{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}"),  // Área de Trabalho
                Reg.CriaChaveM(ThisPC + "{d3162b92-9365-467a-956b-92703aca08af}"),  // Documentos
                Reg.CriaChaveM(ThisPC + "{088e3905-0323-4b02-9826-5d99428e115f}"),  // Downloads
                Reg.CriaChaveM(ThisPC + "{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}"),  // Música
                Reg.CriaChaveM(ThisPC + "{24ad3ad4-a569-4530-98e1-ab02f9417aa8}"),  // Imagens
                Reg.CriaChaveM(ThisPC + "{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}")), // Vídeos

            new Escolha(cExp, "Posição da letra da unidade",
                new Opcao("Depois do nome (padrão)", Reg.M(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer", "ShowDriveLettersFirst", 0)),
                new Opcao("Antes do nome", Reg.M(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer", "ShowDriveLettersFirst", 1)),
                new Opcao("Ocultar letras das unidades de rede", Reg.M(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer", "ShowDriveLettersFirst", 2)),
                new Opcao("Ocultar todas as letras", Reg.M(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer", "ShowDriveLettersFirst", 4))),

            // ================= Recursos opcionais =================
            new Recurso(cRec, "Ativar Windows Sandbox", "Containers-DisposableClientVM"),
            new Recurso(cRec, "Ativar Subsistema do Windows para Linux (WSL)", "Microsoft-Windows-Subsystem-Linux"),

            // ================= Menu Iniciar e Pesquisa =================
            new Escolha(cIni, "Visualização de 'Todos os apps' no Menu Iniciar",
                new Opcao("Categoria", Reg.U(@"Software\Microsoft\Windows\CurrentVersion\Start", "AllAppsViewMode", 0)),
                new Opcao("Grade", Reg.U(@"Software\Microsoft\Windows\CurrentVersion\Start", "AllAppsViewMode", 1)),
                new Opcao("Lista", Reg.U(@"Software\Microsoft\Windows\CurrentVersion\Start", "AllAppsViewMode", 2))),

            new Tweak(cIni, "Ocultar a seção 'Recomendados' do Menu Iniciar",
                Reg.M(Pol + @"\Explorer", "HideRecommendedSection", 1),
                Reg.M(@"SOFTWARE\Microsoft\PolicyManager\current\device\Start", "HideRecommendedSection", 1),
                Reg.M(@"SOFTWARE\Microsoft\PolicyManager\current\device\Education", "IsEducationEnvironment", 1)),

            new Tweak(cIni, "Desativar integração do Phone Link no Menu Iniciar",
                Reg.U(@"Software\Microsoft\Windows\CurrentVersion\Start", "RightCompanionToggledOpen", 0, 1)),

            new Tweak(cIni, "Desativar pesquisa na web do Bing e integração do Copilot na pesquisa",
                Reg.U(@"Software\Policies\Microsoft\Windows\Explorer", "DisableSearchBoxSuggestions", 1),
                Reg.U(@"Software\Microsoft\Windows\CurrentVersion\Search", "BingSearchEnabled", 0, 1)),

            new Tweak(cIni, "Desativar destaques e sugestões dinâmicas na pesquisa",
                Reg.U(@"Software\Microsoft\Windows\CurrentVersion\SearchSettings", "IsDynamicSearchBoxEnabled", 0, 1)),

            // ================= Barra de tarefas =================
            new Tweak(cBarra, "Mostrar 'Finalizar tarefa' no menu de contexto da barra de tarefas",
                Reg.U(Adv + @"\TaskbarDeveloperSettings", "TaskbarEndTask", 1, 0)),

            new Tweak(cBarra, "Ativar comportamento 'Last Active Click' nos apps da barra",
                Reg.U(Adv, "LastActiveClick", 1, 0)),

            new Escolha(cBarra, "Mostrar apps da barra de tarefas em",
                new Opcao("Todas as barras de tarefas",
                    Reg.U(Adv, "MMTaskbarEnabled", 1), Reg.U(Adv, "MMTaskbarMode", 0)),
                new Opcao("Barra principal e onde a janela está aberta",
                    Reg.U(Adv, "MMTaskbarEnabled", 1), Reg.U(Adv, "MMTaskbarMode", 1)),
                new Opcao("Somente onde a janela está aberta",
                    Reg.U(Adv, "MMTaskbarEnabled", 1), Reg.U(Adv, "MMTaskbarMode", 2)),
                new Opcao("Somente a barra principal",
                    Reg.U(Adv, "MMTaskbarEnabled", 0))),

            new Escolha(cBarra, "Combinar botões da barra de tarefas na tela principal",
                new Opcao("Sempre", Reg.U(Adv, "TaskbarGlomLevel", 0)),
                new Opcao("Quando a barra estiver cheia", Reg.U(Adv, "TaskbarGlomLevel", 1)),
                new Opcao("Nunca", Reg.U(Adv, "TaskbarGlomLevel", 2))),

            new Escolha(cBarra, "Combinar botões da barra de tarefas nas telas secundárias",
                new Opcao("Sempre", Reg.U(Adv, "MMTaskbarGlomLevel", 0)),
                new Opcao("Quando a barra estiver cheia", Reg.U(Adv, "MMTaskbarGlomLevel", 1)),
                new Opcao("Nunca", Reg.U(Adv, "MMTaskbarGlomLevel", 2))),

            // ================= Jogos =================
            new Tweak(cJogo, "Desativar gravação de jogo/tela do Xbox",
                Reg.U(@"System\GameConfigStore", "GameDVR_Enabled", 0, 1),
                Reg.U(@"Software\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", 0, 1),
                Reg.M(Pol + @"\GameDVR", "AllowGameDVR", 0)),

            new Tweak(cJogo, "Desativar integração com a Game Bar",
                Reg.U(@"Software\Microsoft\GameBar", "UseNexusForGameBarEnabled", 0, 1),
                Reg.U(@"Software\Microsoft\GameBar", "ShowStartupPanel", 0, 1)),

            // ================= Outros =================
            new Tweak(cOutros, "Ocultar a página 'Início' das Configurações",
                Reg.M(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer", "SettingsPageVisibility", "hide:home")),

            new Tweak(cOutros, "Desativar bloatware do navegador Brave (IA, Cripto, Rewards, VPN)",
                Reg.M(@"SOFTWARE\Policies\BraveSoftware\Brave", "BraveRewardsDisabled", 1),
                Reg.M(@"SOFTWARE\Policies\BraveSoftware\Brave", "BraveWalletDisabled", 1),
                Reg.M(@"SOFTWARE\Policies\BraveSoftware\Brave", "BraveVPNDisabled", 1),
                Reg.M(@"SOFTWARE\Policies\BraveSoftware\Brave", "BraveAIChatEnabled", 0),
                Reg.M(@"SOFTWARE\Policies\BraveSoftware\Brave", "BraveStatsPingEnabled", 0)),
        };
    }
}