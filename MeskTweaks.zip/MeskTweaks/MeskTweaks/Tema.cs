﻿using Sunny.UI;
using System.Security.Principal;

namespace MeskTweaks
{
    // Paleta e estilos compartilhados (mesmas cores do Form1)
    internal static class Tema
    {
        public static readonly Color Fundo = ColorTranslator.FromHtml("#0B0714");
        public static readonly Color Superficie = ColorTranslator.FromHtml("#150E26");
        public static readonly Color Primaria = ColorTranslator.FromHtml("#7C3AED");
        public static readonly Color Hover = ColorTranslator.FromHtml("#9D5CFF");
        public static readonly Color Press = ColorTranslator.FromHtml("#5B21B6");
        public static readonly Color Destaque = ColorTranslator.FromHtml("#C084FC");
        public static readonly Color Texto = ColorTranslator.FromHtml("#F3E8FF");
        public static readonly Color TextoSuave = ColorTranslator.FromHtml("#9F8FC4");

        public static void EstilizarBotao(UIButton b, bool preenchido)
        {
            b.StyleCustomMode = true;
            b.Style = UIStyle.Custom;
            b.Radius = 14;
            b.RectColor = Primaria;
            b.RectHoverColor = Hover;
            b.RectPressColor = Press;
            b.ForeColor = Color.White;
            b.ForeHoverColor = Color.White;
            b.ForePressColor = Color.White;

            if (preenchido)
            {
                b.FillColor = Primaria;
                b.FillHoverColor = Hover;
                b.FillPressColor = Press;
            }
            else
            {
                b.FillColor = Superficie;
                b.FillHoverColor = Press;
                b.FillPressColor = Primaria;
            }
        }

        public static bool EhAdministrador()
        {
            using var id = WindowsIdentity.GetCurrent();
            return new WindowsPrincipal(id).IsInRole(WindowsBuiltInRole.Administrator);
        }
    }
}