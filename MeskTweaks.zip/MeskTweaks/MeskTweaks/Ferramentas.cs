﻿using System.IO.Compression;
using System.Net.Http;

namespace MeskTweaks
{
    /// <summary>
    /// Baixa um .zip, extrai em uma pasta temporária e executa o programa de dentro dele.
    /// </summary>
    public static class Ferramentas
    {
        public static async Task<(bool Sucesso, string Mensagem)> BaixarExtrairExecutarAsync(
            string urlZip, string nomeFerramenta, string? nomeExecutavelPreferido = null,
            IProgress<string>? progresso = null)
        {
            try
            {
                string pastaBase = Path.Combine(Path.GetTempPath(), "MeskTweaks", nomeFerramenta);
                string zipPath = Path.Combine(Path.GetTempPath(), "MeskTweaks", nomeFerramenta + ".zip");

                // pasta limpa a cada execução
                if (Directory.Exists(pastaBase))
                    Directory.Delete(pastaBase, true);
                Directory.CreateDirectory(pastaBase);

                // ---------- baixar ----------
                progresso?.Report("Baixando " + nomeFerramenta + "...");
                using (var http = new HttpClient())
                {
                    http.Timeout = TimeSpan.FromMinutes(5);
                    using var resposta = await http.GetAsync(urlZip, HttpCompletionOption.ResponseHeadersRead);
                    resposta.EnsureSuccessStatusCode();

                    using var streamHttp = await resposta.Content.ReadAsStreamAsync();
                    using var streamArquivo = File.Create(zipPath);
                    await streamHttp.CopyToAsync(streamArquivo);
                }

                // ---------- extrair ----------
                progresso?.Report("Extraindo " + nomeFerramenta + "...");
                ZipFile.ExtractToDirectory(zipPath, pastaBase, overwriteFiles: true);
                try { File.Delete(zipPath); } catch { }

                // ---------- achar o executável ----------
                string? exe = null;

                if (nomeExecutavelPreferido != null)
                    exe = Directory.GetFiles(pastaBase, nomeExecutavelPreferido, SearchOption.AllDirectories)
                                    .FirstOrDefault();

                if (exe == null)
                    exe = Directory.GetFiles(pastaBase, "*.exe", SearchOption.AllDirectories)
                                    .FirstOrDefault();

                if (exe == null)
                    return (false, "Nenhum executável (.exe) encontrado dentro do .zip.");

                // ---------- executar ----------
                progresso?.Report("Executando " + Path.GetFileName(exe) + "...");
                var psi = new System.Diagnostics.ProcessStartInfo(exe)
                {
                    WorkingDirectory = Path.GetDirectoryName(exe) ?? pastaBase,
                    UseShellExecute = true
                };
                System.Diagnostics.Process.Start(psi);

                return (true, "Executado a partir de: " + exe);
            }
            catch (Exception ex)
            {
                return (false, ex.Message);
            }
        }
    }
}