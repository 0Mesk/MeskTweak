﻿#nullable disable
namespace MeskTweaks
{
    partial class Form2
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer do Windows Forms

        private void InitializeComponent()
        {
            lblTitulo = new Label();
            lblDescricao = new Label();
            txtBusca = new TextBox();
            pnlLista = new Panel();
            btnVoltar = new Sunny.UI.UIButton();
            btnLimpar = new Sunny.UI.UIButton();
            btnDetectar = new Sunny.UI.UIButton();
            btnReverter = new Sunny.UI.UIButton();
            btnAplicar = new Sunny.UI.UIButton();
            lblStatus = new Label();
            SuspendLayout();
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.BackColor = Color.Transparent;
            lblTitulo.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblTitulo.ForeColor = Color.FromArgb(243, 232, 255);
            lblTitulo.Location = new Point(46, 45);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(300, 45);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Tweaks avançados";
            // 
            // lblDescricao
            // 
            lblDescricao.BackColor = Color.Transparent;
            lblDescricao.Font = new Font("Segoe UI", 10F);
            lblDescricao.ForeColor = Color.FromArgb(159, 143, 196);
            lblDescricao.Location = new Point(50, 98);
            lblDescricao.Name = "lblDescricao";
            lblDescricao.Size = new Size(900, 24);
            lblDescricao.TabIndex = 1;
            lblDescricao.Text = "Marque o que deseja mudar e clique em \"Aplicar selecionados\". Itens marcados com (admin) exigem Administrador.";
            // 
            // txtBusca
            // 
            txtBusca.BackColor = Color.FromArgb(21, 14, 38);
            txtBusca.BorderStyle = BorderStyle.FixedSingle;
            txtBusca.Font = new Font("Segoe UI", 11F);
            txtBusca.ForeColor = Color.FromArgb(243, 232, 255);
            txtBusca.Location = new Point(690, 56);
            txtBusca.Name = "txtBusca";
            txtBusca.PlaceholderText = "Buscar tweaks...";
            txtBusca.Size = new Size(260, 27);
            txtBusca.TabIndex = 2;
            txtBusca.TextChanged += txtBusca_TextChanged;
            // 
            // pnlLista
            // 
            pnlLista.AutoScroll = true;
            pnlLista.BackColor = Color.FromArgb(21, 14, 38);
            pnlLista.Location = new Point(50, 135);
            pnlLista.Name = "pnlLista";
            pnlLista.Size = new Size(900, 375);
            pnlLista.TabIndex = 3;
            // 
            // btnVoltar
            // 
            btnVoltar.Cursor = Cursors.Hand;
            btnVoltar.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            btnVoltar.Location = new Point(50, 525);
            btnVoltar.MinimumSize = new Size(1, 1);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(130, 46);
            btnVoltar.TabIndex = 4;
            btnVoltar.Text = "← Voltar";
            btnVoltar.TipsFont = new Font("Microsoft Sans Serif", 9F);
            btnVoltar.Click += btnVoltar_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Cursor = Cursors.Hand;
            btnLimpar.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            btnLimpar.Location = new Point(190, 525);
            btnLimpar.MinimumSize = new Size(1, 1);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(150, 46);
            btnLimpar.TabIndex = 5;
            btnLimpar.Text = "Limpar seleção";
            btnLimpar.TipsFont = new Font("Microsoft Sans Serif", 9F);
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnDetectar
            // 
            btnDetectar.Cursor = Cursors.Hand;
            btnDetectar.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            btnDetectar.Location = new Point(350, 525);
            btnDetectar.MinimumSize = new Size(1, 1);
            btnDetectar.Name = "btnDetectar";
            btnDetectar.Size = new Size(170, 46);
            btnDetectar.TabIndex = 6;
            btnDetectar.Text = "Detectar aplicados";
            btnDetectar.TipsFont = new Font("Microsoft Sans Serif", 9F);
            btnDetectar.Click += btnDetectar_Click;
            // 
            // btnReverter
            // 
            btnReverter.Cursor = Cursors.Hand;
            btnReverter.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            btnReverter.Location = new Point(530, 525);
            btnReverter.MinimumSize = new Size(1, 1);
            btnReverter.Name = "btnReverter";
            btnReverter.Size = new Size(190, 46);
            btnReverter.TabIndex = 7;
            btnReverter.Text = "Reverter selecionados";
            btnReverter.TipsFont = new Font("Microsoft Sans Serif", 9F);
            btnReverter.Click += btnReverter_Click;
            // 
            // btnAplicar
            // 
            btnAplicar.Cursor = Cursors.Hand;
            btnAplicar.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            btnAplicar.Location = new Point(730, 525);
            btnAplicar.MinimumSize = new Size(1, 1);
            btnAplicar.Name = "btnAplicar";
            btnAplicar.Size = new Size(220, 46);
            btnAplicar.TabIndex = 8;
            btnAplicar.Text = "Aplicar selecionados";
            btnAplicar.TipsFont = new Font("Microsoft Sans Serif", 9F);
            btnAplicar.Click += btnAplicar_Click;
            // 
            // lblStatus
            // 
            lblStatus.BackColor = Color.Transparent;
            lblStatus.Font = new Font("Segoe UI", 10.5F);
            lblStatus.ForeColor = Color.FromArgb(192, 132, 252);
            lblStatus.Location = new Point(50, 585);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(900, 30);
            lblStatus.TabIndex = 9;
            lblStatus.Text = "Pronto.";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 640);
            Controls.Add(lblStatus);
            Controls.Add(btnAplicar);
            Controls.Add(btnReverter);
            Controls.Add(btnDetectar);
            Controls.Add(btnLimpar);
            Controls.Add(btnVoltar);
            Controls.Add(pnlLista);
            Controls.Add(txtBusca);
            Controls.Add(lblDescricao);
            Controls.Add(lblTitulo);
            MinimumSize = new Size(900, 600);
            Name = "Form2";
            Padding = new Padding(0, 35, 0, 0);
            ShowTitleIcon = true;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MeskTweaks - Tweaks avançados";
            FormClosed += Form2_FormClosed;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitulo;
        private Label lblDescricao;
        private TextBox txtBusca;
        private Panel pnlLista;
        private Sunny.UI.UIButton btnVoltar;
        private Sunny.UI.UIButton btnLimpar;
        private Sunny.UI.UIButton btnDetectar;
        private Sunny.UI.UIButton btnReverter;
        private Sunny.UI.UIButton btnAplicar;
        private Label lblStatus;
    }
}