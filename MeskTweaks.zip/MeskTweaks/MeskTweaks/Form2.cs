﻿using Sunny.UI;

namespace MeskTweaks
{
    public partial class Form2 : UIForm
    {
        // Definido pelo Form1 antes de chamar Show()
        internal Form1? Principal { get; set; }

        private readonly HashSet<Item> _marcados = new();
        private bool _construindo;
        private bool _voltando;

        public Form2()
        {
            InitializeComponent();
            AplicarTema();
            ConstruirLista();
        }

        private void AplicarTema()
        {
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

            StyleCustomMode = true;
            Style = UIStyle.Custom;
            BackColor = Tema.Fundo;
            ForeColor = Tema.Texto;
            TitleColor = Tema.Superficie;
            TitleForeColor = Tema.Texto;
            RectColor = Tema.Primaria;
            ShowIcon = true;
            ShowTitleIcon = true;

            Tema.EstilizarBotao(btnVoltar, preenchido: false);
            Tema.EstilizarBotao(btnLimpar, preenchido: false);
            Tema.EstilizarBotao(btnDetectar, preenchido: false);
            Tema.EstilizarBotao(btnReverter, preenchido: false);
            Tema.EstilizarBotao(btnAplicar, preenchido: true);
        }

        // =================== Navegação ===================

        private void btnVoltar_Click(object? sender, EventArgs e)
        {
            _voltando = true;

            if (Principal != null)
            {
                Principal.StartPosition = FormStartPosition.Manual;
                Principal.Location = Location;
                Principal.Show();
            }

            Close();
        }

        // Se fechar pelo X (sem usar Voltar), encerra o programa todo
        private void Form2_FormClosed(object? sender, FormClosedEventArgs e)
        {
            if (!_voltando)
                Principal?.Close();
        }

        // =================== Lista de tweaks ===================

        private static string Rotulo(Item i) => i.Texto + (i.RequerAdmin ? "  (admin)" : "");

        private void ConstruirLista()
        {
            _construindo = true;
            pnlLista.SuspendLayout();

            foreach (var c in pnlLista.Controls.Cast<Control>().ToList())
                c.Dispose();
            pnlLista.Controls.Clear();

            string busca = txtBusca.Text.Trim();
            int y = 8;

            foreach (var grupo in Tweaks.Lista.GroupBy(t => t.Categoria))
            {
                var itens = grupo
                    .Where(t => busca.Length == 0 ||
                                t.Texto.Contains(busca, StringComparison.OrdinalIgnoreCase) ||
                                t.Categoria.Contains(busca, StringComparison.OrdinalIgnoreCase))
                    .ToList();
                if (itens.Count == 0) continue;

                pnlLista.Controls.Add(new Label
                {
                    AutoSize = false,
                    BackColor = Color.Transparent,
                    Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                    ForeColor = Tema.Destaque,
                    Location = new Point(12, y),
                    Size = new Size(840, 30),
                    Text = grupo.Key
                });
                y += 36;

                foreach (var item in itens)
                {
                    if (item is Escolha esc)
                    {
                        pnlLista.Controls.Add(new Label
                        {
                            AutoSize = false,
                            BackColor = Color.Transparent,
                            Font = new Font("Segoe UI", 11F),
                            ForeColor = Tema.Texto,
                            Location = new Point(24, y),
                            Size = new Size(820, 26),
                            Text = Rotulo(esc)
                        });

                        var cmb = new ComboBox
                        {
                            DropDownStyle = ComboBoxStyle.DropDownList,
                            FlatStyle = FlatStyle.Flat,
                            Font = new Font("Segoe UI", 10F),
                            BackColor = Tema.Fundo,
                            ForeColor = Tema.Texto,
                            Location = new Point(24, y + 28),
                            Size = new Size(440, 30),
                            Tag = esc
                        };
                        cmb.Items.Add("Sem alteração");
                        foreach (var o in esc.Opcoes) cmb.Items.Add(o.Rotulo);
                        cmb.SelectedIndex = esc.Indice;
                        cmb.SelectedIndexChanged += Cmb_SelectedIndexChanged;
                        pnlLista.Controls.Add(cmb);

                        y += 68;
                    }
                    else
                    {
                        var chk = new CheckBox
                        {
                            AutoSize = false,
                            BackColor = Color.Transparent,
                            Cursor = Cursors.Hand,
                            Font = new Font("Segoe UI", 11F),
                            ForeColor = Tema.Texto,
                            Location = new Point(24, y),
                            Size = new Size(820, 32),
                            Text = Rotulo(item),
                            Tag = item,
                            UseVisualStyleBackColor = false,
                            Checked = _marcados.Contains(item)
                        };
                        chk.CheckedChanged += Chk_CheckedChanged;
                        pnlLista.Controls.Add(chk);

                        y += 34;
                    }
                }

                y += 14;
            }

            pnlLista.ResumeLayout();
            _construindo = false;
            AtualizarStatusSelecao();
        }

        private void Chk_CheckedChanged(object? sender, EventArgs e)
        {
            if (_construindo || sender is not CheckBox { Tag: Item item } chk)
                return;

            if (chk.Checked) _marcados.Add(item);
            else _marcados.Remove(item);

            AtualizarStatusSelecao();
        }

        private void Cmb_SelectedIndexChanged(object? sender, EventArgs e)
        {
            if (_construindo || sender is not ComboBox { Tag: Escolha esc } cmb)
                return;

            esc.Indice = cmb.SelectedIndex;

            if (esc.Indice > 0) _marcados.Add(esc);
            else _marcados.Remove(esc);

            AtualizarStatusSelecao();
        }

        private void AtualizarStatusSelecao()
        {
            lblStatus.Text = _marcados.Count + " tweak(s) selecionado(s).";
        }

        private void txtBusca_TextChanged(object? sender, EventArgs e) => ConstruirLista();

        private void btnLimpar_Click(object? sender, EventArgs e)
        {
            _marcados.Clear();
            foreach (var esc in Tweaks.Lista.OfType<Escolha>())
                esc.Indice = 0;
            ConstruirLista();
        }

        // Marca o que já está aplicado no Windows
        private async void btnDetectar_Click(object? sender, EventArgs e)
        {
            SetBotoes(false);
            lblStatus.Text = "Detectando tweaks aplicados (pode levar alguns segundos)...";

            var aplicados = await Task.Run(() =>
            {
                var res = new List<Item>();
                foreach (var i in Tweaks.Lista)
                {
                    if (i is Escolha e)
                    {
                        e.Indice = e.Detectar();
                        if (e.Indice > 0) res.Add(i);
                    }
                    else if (i.EstaAplicado())
                    {
                        res.Add(i);
                    }
                }
                return res;
            });

            _marcados.Clear();
            foreach (var i in aplicados) _marcados.Add(i);
            ConstruirLista();

            SetBotoes(true);
            lblStatus.Text = aplicados.Count + " tweak(s) já aplicado(s) detectado(s).";
        }

        // =================== Aplicar / Reverter ===================

        private async Task ExecutarAsync(bool aplicar)
        {
            if (_marcados.Count == 0)
            {
                UIMessageBox.ShowWarning("Marque pelo menos um tweak.");
                return;
            }

            var selecionados = _marcados.ToList();

            if (!Tema.EhAdministrador() && selecionados.Any(t => t.RequerAdmin))
            {
                UIMessageBox.ShowError("Alguns itens marcados com (admin) exigem que o programa seja executado como Administrador.");
                return;
            }

            SetBotoes(false);
            lblStatus.Text = aplicar ? "Aplicando..." : "Revertendo...";

            var erros = await Task.Run(() =>
            {
                var lista = new List<string>();
                foreach (var t in selecionados)
                {
                    try
                    {
                        if (aplicar) t.Aplicar();
                        else t.Reverter();
                    }
                    catch (Exception ex)
                    {
                        lista.Add(t.Texto + ": " + ex.Message);
                    }
                }
                return lista;
            });

            SetBotoes(true);

            if (erros.Count == 0)
            {
                lblStatus.Text = aplicar ? "Tweaks aplicados." : "Tweaks revertidos.";
                UIMessageBox.ShowSuccess((aplicar ? "Tweaks aplicados!" : "Tweaks revertidos!") +
                                         "\nAlguns só têm efeito após reiniciar o Explorer, sair da conta ou reiniciar o PC.");
            }
            else
            {
                lblStatus.Text = "Concluído com " + erros.Count + " erro(s).";
                UIMessageBox.ShowWarning("Concluído com " + erros.Count + " erro(s):\n" + string.Join("\n", erros));
            }
        }

        private void SetBotoes(bool ligado)
        {
            btnVoltar.Enabled = ligado;
            btnLimpar.Enabled = ligado;
            btnDetectar.Enabled = ligado;
            btnReverter.Enabled = ligado;
            btnAplicar.Enabled = ligado;
            pnlLista.Enabled = ligado;
            txtBusca.Enabled = ligado;
        }

        private async void btnAplicar_Click(object? sender, EventArgs e) => await ExecutarAsync(true);

        private async void btnReverter_Click(object? sender, EventArgs e) => await ExecutarAsync(false);
    }
}